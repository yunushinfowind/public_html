<?php exit; ?>
/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/options-writing.php

2015-11-01 13:40:39
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/options-writing.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/options-writing.php
Array
(
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvs] => 563678ae07dca15f000
    [gk_last_opened_widget_rules_wrap] => 0
)


