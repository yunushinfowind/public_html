<?php exit; ?>
/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php

2015-11-01 13:39:53
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:40:24
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvs] => 563678ae07dca15f000
    [gk_last_opened_widget_rules_wrap] => 0
)


2015-11-02 03:00:42
IP:175.100.147.23
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|c1d761ed330a9f29ae80305a9dec722b2b8e69b70f530a693de2be281dec9a14
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvs] => 56373273b0591d51001
)


2015-11-02 03:02:21
IP:175.100.147.23
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [_wpnonce] => 90056ca71b
    [_wp_http_referer] => /wp-admin/theme-editor.php
    [newcontent] => /*
Theme Name:  theme54799
Theme URI:   http://yoursite.com/link/to/theme
Description: Your theme description.
Author:      Your Name
Author URI:  http://yoursite.com
Version:     1.0.0
License:     GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags:        fixed-layout, fluid-layout, responsive-layout, left-sidebar, right-sidebar, custom-menu, featured-images, full-width-template, post-formats, sticky-post, theme-options, translation-ready
Text Domain: theme54799
Template:    cherryframework4
*/

/* =Theme customization starts here
-------------------------------------------------------------- */
.home .row.extrabox_3 img {
    clear: both;
    display: block;
    text-align: center;
    margin: auto;
}
    [action] => update
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [submit] => Update File
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|c1d761ed330a9f29ae80305a9dec722b2b8e69b70f530a693de2be281dec9a14
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvc] => 4|44
    [__atuvs] => 56373273b0591d51002
)


2015-11-02 03:02:23
IP:175.100.147.23
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [updated] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|c1d761ed330a9f29ae80305a9dec722b2b8e69b70f530a693de2be281dec9a14
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvs] => 56373273b0591d51002
)


2015-11-02 03:54:48
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c008
)


2015-11-02 03:54:48
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c008
)


2015-11-02 03:55:17
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [_wpnonce] => 2960dd5ce3
    [_wp_http_referer] => /wp-admin/theme-editor.php
    [newcontent] => /*
Theme Name:  theme54799
Theme URI:   http://yoursite.com/link/to/theme
Description: Your theme description.
Author:      Your Name
Author URI:  http://yoursite.com
Version:     1.0.0
License:     GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags:        fixed-layout, fluid-layout, responsive-layout, left-sidebar, right-sidebar, custom-menu, featured-images, full-width-template, post-formats, sticky-post, theme-options, translation-ready
Text Domain: theme54799
Template:    cherryframework4
*/

/* =Theme customization starts here
-------------------------------------------------------------- */
.home .row.extrabox_3 img {
    clear: both;
    display: block;
    text-align: center;
    margin: auto;
}

.home .a{
color : #090909;
}

    [action] => update
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [submit] => Update File
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvc] => 11|44
    [__atuvs] => 56373b7cc6e7bc1c008
)


2015-11-02 03:55:19
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [updated] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c008
)


2015-11-02 03:56:14
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [_wpnonce] => 2960dd5ce3
    [_wp_http_referer] => /wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
    [newcontent] => /*
Theme Name:  theme54799
Theme URI:   http://yoursite.com/link/to/theme
Description: Your theme description.
Author:      Your Name
Author URI:  http://yoursite.com
Version:     1.0.0
License:     GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags:        fixed-layout, fluid-layout, responsive-layout, left-sidebar, right-sidebar, custom-menu, featured-images, full-width-template, post-formats, sticky-post, theme-options, translation-ready
Text Domain: theme54799
Template:    cherryframework4
*/

/* =Theme customization starts here
-------------------------------------------------------------- */
.home .row.extrabox_3 img {
    clear: both;
    display: block;
    text-align: center;
    margin: auto;
}

.home .a{
color : #090909;
}

    [action] => update
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [submit] => Update File
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvc] => 13|44
    [__atuvs] => 56373b7cc6e7bc1c00a
)


2015-11-02 03:56:16
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [updated] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00a
)


2015-11-02 03:56:29
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [_wpnonce] => 2960dd5ce3
    [_wp_http_referer] => /wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
    [newcontent] => 
    [action] => update
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [submit] => Update File
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvc] => 13|44
    [__atuvs] => 56373b7cc6e7bc1c00a
)


2015-11-02 03:56:31
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [updated] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00a
)


2015-11-02 03:57:14
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [_wpnonce] => 2960dd5ce3
    [_wp_http_referer] => /wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
    [newcontent] => /*
Theme Name:  theme54799
Theme URI:   http://yoursite.com/link/to/theme
Description: Your theme description.
Author:      Your Name
Author URI:  http://yoursite.com
Version:     1.0.0
License:     GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags:        fixed-layout, fluid-layout, responsive-layout, left-sidebar, right-sidebar, custom-menu, featured-images, full-width-template, post-formats, sticky-post, theme-options, translation-ready
Text Domain: theme54799
Template:    cherryframework4
*/

/* =Theme customization starts here
-------------------------------------------------------------- */
.home .row.extrabox_3 img {
    clear: both;
    display: block;
    text-align: center;
    margin: auto;
}

.home .a{
color : #090909;
}

    [action] => update
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [submit] => Update File
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvc] => 14|44
    [__atuvs] => 56373b7cc6e7bc1c00b
)


2015-11-02 03:57:16
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [updated] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00b
)


2015-11-02 03:57:34
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [_wpnonce] => 2960dd5ce3
    [_wp_http_referer] => /wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
    [newcontent] => /*
Theme Name:  theme54799
Theme URI:   http://yoursite.com/link/to/theme
Description: Your theme description.
Author:      Your Name
Author URI:  http://yoursite.com
Version:     1.0.0
License:     GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags:        fixed-layout, fluid-layout, responsive-layout, left-sidebar, right-sidebar, custom-menu, featured-images, full-width-template, post-formats, sticky-post, theme-options, translation-ready
Text Domain: theme54799
Template:    cherryframework4
*/

/* =Theme customization starts here
-------------------------------------------------------------- test*/
.home .row.extrabox_3 img {
    clear: both;
    display: block;
    text-align: center;
    margin: auto;
}


    [action] => update
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [submit] => Update File
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvc] => 14|44
    [__atuvs] => 56373b7cc6e7bc1c00b
)


2015-11-02 03:57:36
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [updated] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00b
)


2015-11-02 03:57:40
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&theme=theme54799&scrollto=0&updated=true&GD_COMMAND=FLUSH_CACHE&GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [theme] => theme54799
    [scrollto] => 0
    [updated] => true
    [GD_COMMAND] => FLUSH_CACHE
    [GD_NONCE] => 5b860c70f7
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00b
)


2015-11-02 03:57:41
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/theme-editor.php?file=style.css&
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/theme-editor.php
Array
(
    [file] => style.css
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00b
)


