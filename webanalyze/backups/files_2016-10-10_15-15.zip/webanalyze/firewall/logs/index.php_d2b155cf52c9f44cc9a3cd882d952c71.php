<?php exit; ?>
/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php

2015-11-01 00:55:42
IP:157.55.39.33
Link:http://lessonsonthego.com/miriam-s-.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:09:11
IP:157.55.39.70
Link:http://www.lessonsonthego.com/music/bass-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:21:37
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/audio-format/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:24:10
IP:66.249.79.221
Link:http://lessonsonthego.com/Swimming-Instructors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:30:12
IP:66.249.74.104
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:30:14
IP:66.249.79.228
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:39:13
IP:46.4.123.172
Link:http://lessonsonthego.com/home/cancellation-policy/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:39:34
IP:46.4.123.172
Link:http://lessonsonthego.com/home/cancellation-policy/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:39:42
IP:46.4.123.172
Link:http://lessonsonthego.com/home/careers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:39:48
IP:46.4.123.172
Link:http://lessonsonthego.com/home/careers/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:39:52
IP:46.4.123.172
Link:http://lessonsonthego.com/home/faqs/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:39:59
IP:46.4.123.172
Link:http://lessonsonthego.com/music/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:40:05
IP:46.4.123.172
Link:http://lessonsonthego.com/music/violin-lesson/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 01:40:15
IP:46.4.123.172
Link:http://lessonsonthego.com/privacy-policy/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:06:42
IP:157.55.39.70
Link:http://www.lessonsonthego.com/History-Teachers.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:22:58
IP:123.125.71.114
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:32:46
IP:136.243.5.215
Link:http://lessonsonthego.com/uncategorized/duis-ultricies-pharetra/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:32:50
IP:136.243.5.215
Link:http://lessonsonthego.com/uncategorized/fusce-suscipit-varius/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:32:52
IP:136.243.5.215
Link:http://lessonsonthego.com/uncategorized/programs-groups/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:34:45
IP:157.55.39.30
Link:http://www.lessonsonthego.com/Recital-Questions.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:37:24
IP:66.249.79.235
Link:http://lessonsonthego.com/music-lessons-2/how-young-is-too-young/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:44:09
IP:66.249.79.227
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:50:09
IP:66.249.79.228
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:58:16
IP:54.243.53.148
Link:http://www.lessonsonthego.com/feed
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 02:58:17
IP:54.243.53.148
Link:http://lessonsonthego.com/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 03:04:16
IP:66.249.79.228
Link:http://lessonsonthego.com/music/voice-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 03:04:20
IP:66.249.79.221
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 03:26:59
IP:66.249.79.221
Link:http://lessonsonthego.com/the-unexpected-benefits-of-french-tutoring-for-children/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 03:49:40
IP:141.8.143.176
Link:http://lessonsonthego.com/programs/legacy-pca/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 03:53:11
IP:66.249.79.221
Link:http://lessonsonthego.com/home/careers/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 03:53:24
IP:66.249.79.235
Link:http://lessonsonthego.com/team_member/stefan-m/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 03:54:02
IP:66.249.79.235
Link:http://lessonsonthego.com/team_member/stefan-m/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 04:07:00
IP:157.55.39.28
Link:http://www.lessonsonthego.com/sitemap-misc.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 04:27:05
IP:66.249.79.227
Link:http://www.lessonsonthego.com/sitemap-pt-popups-2015-04.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 04:31:28
IP:207.46.13.111
Link:http://lessonsonthego.com/team_member/cammy-d/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 04:38:39
IP:66.249.79.227
Link:http://www.lessonsonthego.com/sitemap-pt-wpcf7_contact_form-2014-11.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 04:56:28
IP:207.46.13.111
Link:http://lessonsonthego.com/sitemap-pt-page-2013-10.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 04:57:05
IP:123.125.71.34
Link:http://www.lessonsonthego.com/https:/lessonsonthego.com/wp-content/uploads/2015/05/music_room1.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 04:57:07
IP:123.125.71.14
Link:http://lessonsonthego.com/https:/lessonsonthego.com/wp-content/uploads/2015/05/music_room1.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 05:01:00
IP:180.76.15.6
Link:http://www.lessonsonthego.com/home/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 05:09:02
IP:66.249.79.221
Link:http://lessonsonthego.com/music-lessons-2/the-best-keyboards-of-2015/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 05:12:33
IP:54.147.167.81
Link:http://lessonsonthego.com/feed/atom/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 05:15:32
IP:207.46.13.111
Link:http://www.lessonsonthego.com/sitemap.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 05:32:18
IP:89.163.148.58
Link:http://www.lessonsonthego.com/?p=3124
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 3124
)


2015-11-01 05:32:22
IP:89.163.148.58
Link:http://lessonsonthego.com/music-lessons-2/top-5-guitars-for-the-beginning-guitarist/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 05:41:13
IP:188.165.15.205
Link:http://lessonsonthego.com/tutors/history/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 05:46:50
IP:157.55.39.84
Link:http://www.lessonsonthego.com/Recital-Ettiquette.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:11:22
IP:66.249.74.100
Link:http://www.lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:13:48
IP:66.249.79.221
Link:http://lessonsonthego.com/?p=4
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 4
)


2015-11-01 06:22:26
IP:54.235.33.127
Link:http://lessonsonthego.com/feed/atom/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:24:46
IP:66.249.79.228
Link:http://lessonsonthego.com/music-lessons-2/jobs-music-lessons-company/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:26:37
IP:54.187.209.40
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:26:42
IP:54.187.209.40
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:26:46
IP:54.187.209.40
Link:http://lessonsonthego.com/home/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:26:49
IP:54.187.209.40
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:26:53
IP:54.187.209.40
Link:http://lessonsonthego.com/refund-referral-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:26:57
IP:54.187.209.40
Link:http://lessonsonthego.com/testimonials/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:26:59
IP:54.187.209.40
Link:http://lessonsonthego.com/home/cancellation-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:02
IP:54.187.209.40
Link:http://lessonsonthego.com/home/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:05
IP:54.187.209.40
Link:http://lessonsonthego.com/blog/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:08
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:12
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:16
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/math-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:20
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/science-tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:24
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/physics/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:27
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/history/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:30
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/french-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:34
IP:54.187.209.40
Link:http://lessonsonthego.com/tutors/spanish-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:37
IP:54.187.209.40
Link:http://lessonsonthego.com/music/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:46
IP:54.187.209.40
Link:http://lessonsonthego.com/music/violin-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:49
IP:54.187.209.40
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:52
IP:54.187.209.40
Link:http://lessonsonthego.com/music/cello-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:55
IP:54.187.209.40
Link:http://lessonsonthego.com/music/flute-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:27:58
IP:54.187.209.40
Link:http://lessonsonthego.com/music/voice-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:02
IP:54.187.209.40
Link:http://lessonsonthego.com/music/music-theory/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:06
IP:54.187.209.40
Link:http://lessonsonthego.com/music/song-writing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:10
IP:54.187.209.40
Link:http://lessonsonthego.com/programs/recitals/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:29
IP:54.187.209.40
Link:http://lessonsonthego.com/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:33
IP:54.187.209.40
Link:http://lessonsonthego.com/testimonial-view/katherine-f/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:36
IP:54.187.209.40
Link:http://lessonsonthego.com/testimonial-view/becky-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:40
IP:54.187.209.40
Link:http://lessonsonthego.com/violin-pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:46
IP:54.187.209.40
Link:http://lessonsonthego.com/application/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:48
IP:54.187.209.40
Link:http://lessonsonthego.com/tutoring/the-unexpected-benefits-of-french-tutoring-for-children/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:52
IP:54.187.209.40
Link:http://lessonsonthego.com/music-lessons-2/the-best-keyboards-of-2015/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:28:59
IP:54.187.209.40
Link:http://lessonsonthego.com/tutoring/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:29:01
IP:54.187.209.40
Link:http://lessonsonthego.com/tutoring/apply-to-work-for-a-tutoring-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:29:06
IP:54.187.209.40
Link:http://lessonsonthego.com/music-lessons-2/jobs-music-lessons-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:29:08
IP:54.187.209.40
Link:http://lessonsonthego.com/music-lessons-2/top-5-guitars-for-the-beginning-guitarist/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:29:12
IP:54.187.209.40
Link:http://lessonsonthego.com/tutoring/how-much-tutoring-does-a-studnet-need/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:29:15
IP:54.187.209.40
Link:http://lessonsonthego.com/music-lessons-2/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:29:19
IP:54.187.209.40
Link:http://lessonsonthego.com/music-lessons-2/how-young-is-too-young/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:29:22
IP:54.187.209.40
Link:http://lessonsonthego.com/english-writing-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:39:01
IP:207.46.13.111
Link:http://www.lessonsonthego.com/sitemap-pt-post-2013-02.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:42:25
IP:52.21.22.209
Link:http://lessonsonthego.com/apple-touch-icon.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:14
IP:173.236.59.218
Link:http://lessonsonthego.com/th1s_1s_a_4o4.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:18
IP:173.236.59.218
Link:http://lessonsonthego.com/?=Search&s=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [s] => 1
)


2015-11-01 06:55:27
IP:173.236.59.218
Link:http://lessonsonthego.com/?p=2
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 2
)


2015-11-01 06:55:28
IP:173.236.59.218
Link:http://lessonsonthego.com/?p=47
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 47
)


2015-11-01 06:55:28
IP:173.236.59.218
Link:http://lessonsonthego.com/?p=1998
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 1998
)


2015-11-01 06:55:29
IP:173.236.59.218
Link:http://lessonsonthego.com/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:32
IP:173.236.59.218
Link:http://lessonsonthego.com/?p=3201
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 3201
)


2015-11-01 06:55:32
IP:173.236.59.218
Link:http://lessonsonthego.com/music/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:33
IP:173.236.59.218
Link:http://lessonsonthego.com/music/song-writing
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:34
IP:173.236.59.218
Link:http://lessonsonthego.com/how-much-tutoring-does-a-studnet-need/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:36
IP:173.236.59.218
Link:http://lessonsonthego.com/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:38
IP:173.236.59.218
Link:http://lessonsonthego.com/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:41
IP:173.236.59.218
Link:http://lessonsonthego.com/contactus/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:43
IP:173.236.59.218
Link:http://lessonsonthego.com/viola-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:44
IP:173.236.59.218
Link:http://lessonsonthego.com/testimonials/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:51
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:51
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/diane_m/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:53
IP:173.236.59.218
Link:http://lessonsonthego.com/music/flute-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:54
IP:173.236.59.218
Link:http://lessonsonthego.com/music/bass-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:54
IP:173.236.59.218
Link:http://lessonsonthego.com/music/bass-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:56
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/stefan-m/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:57
IP:173.236.59.218
Link:http://lessonsonthego.com/how-much-tutoring-does-a-studnet-need/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:58
IP:173.236.59.218
Link:http://lessonsonthego.com/violin-pricing/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:55:59
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/biology
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:00
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/biology/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:01
IP:173.236.59.218
Link:http://lessonsonthego.com/music/banjo-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:03
IP:173.236.59.218
Link:http://lessonsonthego.com/music/banjo-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:04
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/sandra-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:06
IP:173.236.59.218
Link:http://lessonsonthego.com/what-do-i-need-prepared-for-a-music-lesson/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:07
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/history
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:08
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/chris-evans/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:09
IP:173.236.59.218
Link:http://lessonsonthego.com/music/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:09
IP:173.236.59.218
Link:http://lessonsonthego.com/music/music-theory
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:11
IP:173.236.59.218
Link:http://lessonsonthego.com/comments/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:12
IP:173.236.59.218
Link:http://lessonsonthego.com/music/saxophone-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:12
IP:173.236.59.218
Link:http://lessonsonthego.com/music/saxophone-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:14
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/spanish-teachers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:16
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/eric-b/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:18
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/monica-e/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:20
IP:173.236.59.218
Link:http://lessonsonthego.com/home/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:21
IP:173.236.59.218
Link:http://lessonsonthego.com/blog/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:21
IP:173.236.59.218
Link:http://lessonsonthego.com/category/music-lessons-2/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:23
IP:173.236.59.218
Link:http://lessonsonthego.com/contacts/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:23
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/rachel-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:24
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/lorrie-r/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:25
IP:173.236.59.218
Link:http://lessonsonthego.com/testimonial-view/rebecca-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:26
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/english-writing-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:27
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/physics
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:27
IP:173.236.59.218
Link:http://lessonsonthego.com/application/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:28
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/economics-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:28
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/economics-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:29
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/corey-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:30
IP:173.236.59.218
Link:http://lessonsonthego.com/contacts/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:31
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/sam-k/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:32
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/tyler-l/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:33
IP:173.236.59.218
Link:http://lessonsonthego.com/careers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:33
IP:173.236.59.218
Link:http://lessonsonthego.com/pricing/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:34
IP:173.236.59.218
Link:http://lessonsonthego.com/viola-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:34
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/charles-d/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:35
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/cammy-d/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:36
IP:173.236.59.218
Link:http://lessonsonthego.com/category/blog/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:38
IP:173.236.59.218
Link:http://lessonsonthego.com/music/violin-lesson
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:39
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/megan-l/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:41
IP:173.236.59.218
Link:http://lessonsonthego.com/tutors/math-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:42
IP:173.236.59.218
Link:http://lessonsonthego.com/recital-etiquette/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:43
IP:173.236.59.218
Link:http://lessonsonthego.com/recital-registration/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:44
IP:173.236.59.218
Link:http://lessonsonthego.com/commonly-asked-recital-questions
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:45
IP:173.236.59.218
Link:http://lessonsonthego.com/practicing-for-a-recital/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:46
IP:173.236.59.218
Link:http://lessonsonthego.com/testimonial-view/cathy-r/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:47
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/heather-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:48
IP:173.236.59.218
Link:http://lessonsonthego.com/music/cello-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:49
IP:173.236.59.218
Link:http://lessonsonthego.com/violin-pricing/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:50
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/julie-c/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:51
IP:173.236.59.218
Link:http://lessonsonthego.com/contactus/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:51
IP:173.236.59.218
Link:http://lessonsonthego.com/recital-etiquette/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:52
IP:173.236.59.218
Link:http://lessonsonthego.com/practicing-for-a-recital/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:52
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/linda-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:54
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/mike-f/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:56
IP:173.236.59.218
Link:http://lessonsonthego.com/music/clarinet
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:56
IP:173.236.59.218
Link:http://lessonsonthego.com/music/clarinet/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:57
IP:173.236.59.218
Link:http://lessonsonthego.com/testimonial-view/shilpi-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:58
IP:173.236.59.218
Link:http://lessonsonthego.com/pricing/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:59
IP:173.236.59.218
Link:http://lessonsonthego.com/testimonial-view/sherrie-l/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:56:59
IP:173.236.59.218
Link:http://lessonsonthego.com/category/tutor/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:01
IP:173.236.59.218
Link:http://lessonsonthego.com/refund-referral-policy/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:01
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/ana-a/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:02
IP:173.236.59.218
Link:http://lessonsonthego.com/music/drum-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:04
IP:173.236.59.218
Link:http://lessonsonthego.com/music/voice-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:05
IP:173.236.59.218
Link:http://lessonsonthego.com/music/mandolin
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:06
IP:173.236.59.218
Link:http://lessonsonthego.com/music/mandolin/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:07
IP:173.236.59.218
Link:http://lessonsonthego.com/testimonials/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:09
IP:173.236.59.218
Link:http://lessonsonthego.com/team_member/skyler-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 06:57:59
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap-pt-post-2014-07.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:12:56
IP:207.46.13.186
Link:http://www.lessonsonthego.com/sitemap-pt-page-2012-01.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:34:01
IP:180.76.15.147
Link:http://www.lessonsonthego.com/team_member/skyler-j/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:34:03
IP:180.76.15.139
Link:http://lessonsonthego.com/team_member/skyler-j/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:35:33
IP:66.249.79.235
Link:http://lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:35:47
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio_tag/cumque/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:39:03
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio_tag/cumque/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:40:32
IP:66.249.79.221
Link:http://lessonsonthego.com/tutoring/apply-to-work-for-a-tutoring-company/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:43:27
IP:207.46.13.42
Link:http://www.lessonsonthego.com/French-Tutors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:44:13
IP:66.249.79.213
Link:http://www.lessonsonthego.com/sitemap-pt-page-2015-02.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:44:45
IP:66.249.79.228
Link:http://lessonsonthego.com/sitemap-pt-page-2011-09.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:51:40
IP:201.156.164.38
Link:http://www.lessonsonthego.com/Sandra-G-.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:51:41
IP:201.156.164.38
Link:http://www.lessonsonthego.com/team-member/sandra-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:51:42
IP:201.156.164.38
Link:http://lessonsonthego.com/team_member/sandra-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 07:52:39
IP:157.55.39.84
Link:http://www.lessonsonthego.com/Kelsey-F.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 08:12:56
IP:66.249.79.235
Link:http://lessonsonthego.com/maintenance/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 08:28:40
IP:66.249.79.221
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/css/select2.css?ver=4.3.1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 4.3.1
)


2015-11-01 08:28:42
IP:66.249.79.221
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.5
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 3.1.5
)


2015-11-01 08:28:44
IP:66.249.79.235
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/select2/select2.min.js?ver=3.5.2
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 3.5.2
)


2015-11-01 08:28:46
IP:66.249.79.228
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:28:47
IP:66.249.79.221
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:28:50
IP:66.249.79.221
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:28:51
IP:66.249.79.228
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.70
)


2015-11-01 08:28:53
IP:66.249.79.228
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/css/prettyPhoto.css?ver=4.3.1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 4.3.1
)


2015-11-01 08:28:55
IP:66.249.79.235
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:28:56
IP:66.249.79.235
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.init.min.js?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:29:03
IP:66.249.79.221
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:29:03
IP:66.249.79.228
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js?ver=1.4.1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 1.4.1
)


2015-11-01 08:29:06
IP:66.249.79.228
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:29:08
IP:66.249.79.221
Link:http://lessonsonthego.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=2.4.8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 2.4.8
)


2015-11-01 08:42:00
IP:180.76.15.22
Link:http://www.lessonsonthego.com/?p=2033
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 2033
)


2015-11-01 08:56:19
IP:66.249.79.235
Link:http://lessonsonthego.com/tutoring/how-much-tutoring-does-a-studnet-need/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 09:15:03
IP:66.249.74.104
Link:http://www.lessonsonthego.com/sitemap-pt-page-0000-00.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 09:43:32
IP:141.8.143.176
Link:http://lessonsonthego.com/our-staff/archives/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:07:17
IP:52.91.143.41
Link:http://lessonsonthego.com/tutors/french-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:09:41
IP:52.91.143.41
Link:http://lessonsonthego.com/music/drum-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:12:06
IP:66.249.79.228
Link:http://lessonsonthego.com/music-lessons-2/top-5-guitars-for-the-beginning-guitarist/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:17:03
IP:52.91.143.41
Link:http://lessonsonthego.com/tutors/science-tutors
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:18:33
IP:52.91.143.41
Link:http://lessonsonthego.com/music/violin-teacher
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:40:15
IP:141.8.143.176
Link:http://lessonsonthego.com/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/contactus
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:40:18
IP:141.8.143.176
Link:http://lessonsonthego.com/contactus/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:56:17
IP:66.249.79.228
Link:http://lessonsonthego.com/music/piano-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 10:59:07
IP:66.249.79.235
Link:http://lessonsonthego.com/wp-content/uploads/2014/04/Sandra-G-element175.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 11:06:46
IP:188.165.15.205
Link:http://lessonsonthego.com/music/flute-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 11:17:31
IP:100.43.85.5
Link:http://lessonsonthego.com/programs/recitals/commonly-asked-recital-questions/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 11:25:26
IP:100.43.85.25
Link:http://lessonsonthego.com/programs/recitals/recital-ettiquette/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 11:27:53
IP:66.249.79.228
Link:http://lessonsonthego.com/music/guitar-teachers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 11:27:54
IP:66.249.79.235
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 11:30:47
IP:45.27.217.197
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56365a126cb2be55000
)


2015-11-01 12:06:01
IP:195.154.156.209
Link:http://lessonsonthego.com/music/cello-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:04
IP:195.154.156.209
Link:http://lessonsonthego.com/music/cello-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:09
IP:195.154.156.209
Link:http://lessonsonthego.com/music/drum-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:11
IP:195.154.156.209
Link:http://lessonsonthego.com/music/drum-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:16
IP:195.154.156.209
Link:http://lessonsonthego.com/music/guitar-teachers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:22
IP:195.154.156.209
Link:http://lessonsonthego.com/music/music-theory
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:24
IP:195.154.156.209
Link:http://lessonsonthego.com/music/music-theory/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:29
IP:195.154.156.209
Link:http://lessonsonthego.com/music/piano-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:32
IP:54.187.209.40
Link:http://lessonsonthego.com/tutoring/how-to-test-prep/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:36
IP:195.154.156.209
Link:http://lessonsonthego.com/music/viola-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:39
IP:195.154.156.209
Link:http://lessonsonthego.com/music/viola-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:45
IP:195.154.156.209
Link:http://lessonsonthego.com/music/violin-lesson
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:47
IP:195.154.156.209
Link:http://lessonsonthego.com/music/violin-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:51
IP:195.154.156.209
Link:http://lessonsonthego.com/music/voice-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:56
IP:54.187.209.40
Link:http://lessonsonthego.com/english-writing-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:06:58
IP:195.154.156.209
Link:http://lessonsonthego.com/the-best-keyboards-of-2015
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:14
IP:195.154.156.209
Link:http://lessonsonthego.com/the-unexpected-benefits-of-french-tutoring-for-children
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:19
IP:195.154.156.209
Link:http://lessonsonthego.com/top-5-guitars-for-the-beginning-guitarist
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:23
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/biology
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:25
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/biology/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:30
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/english-writing-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:36
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/french-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:46
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/history
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:53
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/math-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:07:55
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/math-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:08:00
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/science-tutors
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:08:03
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/science-tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:08:08
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/spanish-teachers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:08:10
IP:195.154.156.209
Link:http://lessonsonthego.com/tutors/spanish-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:08:13
IP:195.154.156.209
Link:http://www.lessonsonthego.com/Cello-Instructors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:08:15
IP:195.154.156.209
Link:http://www.lessonsonthego.com/music/cello-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:10:49
IP:195.154.60.171
Link:http://lessonsonthego.com/asdsad
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:39:12
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=7c20dd1e-a66e-4f21-a60b-b28e9f8821c1&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => 7c20dd1e-a66e-4f21-a60b-b28e9f8821c1
    [nocache] => 1
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D15%26sessionPageCount%3D2%26lastVisitedAt%3D1446207563161%26weeklySessionCount%3D11%26lastSessionAt%3D1446204476490
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 12:40:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-content/plugins/wp-smushit/assets/css/images/ui-icons_222222_256x240.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 12:43:43
IP:66.249.79.235
Link:http://lessonsonthego.com/music-lessons-2/what-do-i-need-prepared-for-a-music-lesson/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 13:13:00
IP:85.25.199.203
Link:http://lessonsonthego.com/wp/xmlrpc.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 13:40:10
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp_customize] => on
    [theme] => theme54799
    [customized] => {}
    [nonce] => b0cb14586d
    [customize_messenger_channel] => preview-0
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:42:32
IP:76.31.253.156
Link:http://lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvs] => 563678ae07dca15f000
    [gk_last_opened_widget_rules_wrap] => 0
)


2015-11-01 13:43:45
IP:76.31.253.156
Link:http://lessonsonthego.com/sitemap-misc.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvs] => 563678ae07dca15f000
    [gk_last_opened_widget_rules_wrap] => 0
)


2015-11-01 13:43:51
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvs] => 563678ae07dca15f000
    [gk_last_opened_widget_rules_wrap] => 0
)


2015-11-01 13:43:56
IP:76.31.253.156
Link:http://lessonsonthego.com/sitemap.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:44:10
IP:76.31.253.156
Link:http://lessonsonthego.com/sitemap-misc.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:44:12
IP:76.31.253.156
Link:http://lessonsonthego.com/sitemap.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:44:53
IP:76.31.253.156
Link:http://lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:45:52
IP:209.15.21.118
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 13:51:44
IP:68.180.228.97
Link:http://lessonsonthego.com/how-to-test-prep/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 13:52:59
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap-pt-team_member-2015-10.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 13:55:46
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:59:27
IP:66.249.79.235
Link:http://lessonsonthego.com/home/cancellation-policy/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:06:27
IP:76.31.253.156
Link:http://lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:09:09
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:09:21
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvs] => 563678ae07dca15f003
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:14:54
IP:180.76.15.140
Link:http://lessonsonthego.com/music/mandolin/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:19
IP:184.154.36.178
Link:http://lessonsonthego.com/th1s_1s_a_4o4.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:26
IP:184.154.36.178
Link:http://lessonsonthego.com/home/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:30
IP:184.154.36.178
Link:http://lessonsonthego.com/music/song-writing/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:32
IP:184.154.36.178
Link:http://lessonsonthego.com/programs/recitals/practicing-for-a-recital/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:33
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/spanish-teachers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:44
IP:184.154.36.178
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:30:50
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/economics-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:30:52
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/spanish-teachers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:30:53
IP:184.154.36.178
Link:http://lessonsonthego.com/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:55
IP:184.154.36.178
Link:http://lessonsonthego.com/home/careers/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:55
IP:184.154.36.178
Link:http://lessonsonthego.com/testimonial-view/becky-p/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:30:56
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/kaylan-b/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:30:59
IP:184.154.36.178
Link:http://lessonsonthego.com/home/careers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:12
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/ana-a/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:14
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/anthony-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:25
IP:184.154.36.178
Link:http://lessonsonthego.com/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:26
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/biology/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:27
IP:184.154.36.178
Link:http://lessonsonthego.com/pricing/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:30
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/economics-tutoring/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:30
IP:184.154.36.178
Link:http://lessonsonthego.com/music/guitar-teachers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:35
IP:184.154.36.178
Link:http://lessonsonthego.com/programs/recitals/practicing-for-a-recital/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:38
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/science-tutors/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:39
IP:184.154.36.178
Link:http://lessonsonthego.com/music/drum-lessons/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:39
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/english-writing-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:41
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/monica-e/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:42
IP:184.154.36.178
Link:http://lessonsonthego.com/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:43
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/history
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:47
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/diane_m/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:47
IP:184.154.36.178
Link:http://lessonsonthego.com/home/cancellation-policy/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:48
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/marla-b/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:50
IP:184.154.36.178
Link:http://lessonsonthego.com/music/flute-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:51
IP:184.154.36.178
Link:http://lessonsonthego.com/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:52
IP:184.154.36.178
Link:http://lessonsonthego.com/contacts/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:53
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/marla-b/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:53
IP:184.154.36.178
Link:http://lessonsonthego.com/music/violin-lesson/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:54
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:55
IP:184.154.36.178
Link:http://lessonsonthego.com/music/drum-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:55
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/science-tutors
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:56
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/corey-s/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:58
IP:184.154.36.178
Link:http://lessonsonthego.com/contacts/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:31:59
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/anthony-p/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:31:59
IP:184.154.36.178
Link:http://lessonsonthego.com/programs/recitals/commonly-asked-recital-questions/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:00
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/melanie-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:32:01
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:01
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/spanish-teachers/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:32:03
IP:184.154.36.178
Link:http://lessonsonthego.com/music/guitar-teachers/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:32:04
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/camilla-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:32:07
IP:184.154.36.178
Link:http://lessonsonthego.com/pricing/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:08
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/math-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:09
IP:184.154.36.178
Link:http://lessonsonthego.com/testimonials/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:09
IP:184.154.36.178
Link:http://lessonsonthego.com/music/music-theory/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:10
IP:184.154.36.178
Link:http://lessonsonthego.com/team_member/mike-f/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:13
IP:184.154.36.178
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:14
IP:184.154.36.178
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:15
IP:184.154.36.178
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:18
IP:184.154.36.178
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:20
IP:184.154.36.178
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:32:22
IP:184.154.36.178
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:43:17
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=18a3fe4f-8a3f-4b96-b579-5e2278879b93&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => 18a3fe4f-8a3f-4b96-b579-5e2278879b93
    [nocache] => 1
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 14:43:29
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-content/plugins/wp-smushit/assets/css/images/ui-icons_222222_256x240.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 14:44:18
IP:66.249.79.228
Link:http://lessonsonthego.com/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:00:43
IP:69.30.198.202
Link:http://www.lessonsonthego.com/tutors/economics-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:00:49
IP:69.30.198.202
Link:http://lessonsonthego.com/tutors/economics-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:15:14
IP:66.249.79.235
Link:http://lessonsonthego.com/tutoring/how-to-test-prep/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:25:39
IP:5.9.111.70
Link:http://lessonsonthego.com/music/saxophone-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:25:42
IP:5.9.111.70
Link:http://lessonsonthego.com/music/saxophone-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:25:49
IP:5.9.111.70
Link:http://lessonsonthego.com/music/song-writing
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:25:52
IP:5.9.111.70
Link:http://lessonsonthego.com/music/song-writing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:44:27
IP:66.249.79.221
Link:http://lessonsonthego.com/team_member/eric-b/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:45:25
IP:46.4.116.197
Link:http://lessonsonthego.com/?p=2628
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 2628
)


2015-11-01 15:45:29
IP:46.4.116.197
Link:http://lessonsonthego.com/music-lessons-2/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:45:34
IP:46.4.116.197
Link:http://lessonsonthego.com/?p=2711
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 2711
)


2015-11-01 15:45:37
IP:46.4.116.197
Link:http://lessonsonthego.com/tutoring/how-much-tutoring-does-a-studnet-need/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:45:43
IP:46.4.116.197
Link:http://lessonsonthego.com/?p=3124
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 3124
)


2015-11-01 15:45:49
IP:46.4.116.197
Link:http://lessonsonthego.com/?p=3161
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 3161
)


2015-11-01 15:45:53
IP:46.4.116.197
Link:http://lessonsonthego.com/music-lessons-2/jobs-music-lessons-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:45:58
IP:46.4.116.197
Link:http://lessonsonthego.com/?p=3165
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 3165
)


2015-11-01 15:46:01
IP:46.4.116.197
Link:http://lessonsonthego.com/tutoring/apply-to-work-for-a-tutoring-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:49:06
IP:66.249.79.235
Link:http://lessonsonthego.com/team_member/eric-b/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:50:40
IP:172.56.15.123
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:51:10
IP:172.56.15.123
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636974424bc935d000
)


2015-11-01 15:51:25
IP:172.56.15.123
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 15:53:58
IP:1.80.104.150
Link:http://lessonsonthego.com/blog/xmlrpc.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 16:02:20
IP:66.249.79.228
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 16:03:31
IP:188.165.15.205
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/LPCA_Green_Logo.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 16:03:40
IP:66.249.79.221
Link:http://lessonsonthego.com/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 16:04:16
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:08:13
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-content/plugins/wp-smushit/assets/css/images/ui-bg_glass_75_e6e6e6_1x400.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 16:11:35
IP:66.249.79.220
Link:http://www.lessonsonthego.com/sitemap-pt-testi-2015-03.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 16:31:01
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/audio-format/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 16:36:25
IP:94.189.160.103
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636a1f62a511de1000
)


2015-11-01 16:36:33
IP:94.189.160.103
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636a1f62a511de1001
)


2015-11-01 16:36:55
IP:94.189.160.103
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636a1f62a511de1002
)


2015-11-01 16:37:03
IP:94.189.160.103
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636a1f62a511de1003
)


2015-11-01 16:39:45
IP:94.189.160.103
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:14:28
IP:188.165.15.205
Link:http://www.lessonsonthego.com/tutors/spanish-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:15:05
IP:69.30.198.178
Link:http://lessonsonthego.com/?page_id=1998
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [page_id] => 1998
)


2015-11-01 17:15:07
IP:69.30.198.178
Link:http://lessonsonthego.com/music/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:15:15
IP:69.30.198.178
Link:http://lessonsonthego.com/?page_id=2498
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [page_id] => 2498
)


2015-11-01 17:15:17
IP:69.30.198.178
Link:http://lessonsonthego.com/home/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:29:18
IP:173.252.73.121
Link:http://www.lessonsonthego.com/wp-content/uploads/2014/08/logowordpressheader2.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:29:20
IP:173.252.73.98
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/logowordpressheader2.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:32:13
IP:66.249.79.213
Link:http://www.lessonsonthego.com/tutors/tutors/economics-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:32:14
IP:66.249.79.228
Link:http://lessonsonthego.com/tutors/economics-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:42:55
IP:100.43.90.12
Link:http://lessonsonthego.com/jobs-music-lessons-company/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 17:46:48
IP:66.249.79.228
Link:http://lessonsonthego.com/music/piano-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 18:00:39
IP:71.11.172.143
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636b5b11d5d42a5000
)


2015-11-01 18:01:01
IP:71.11.172.143
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636b5c8c895a1be000
)


2015-11-01 18:01:14
IP:71.11.172.143
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636b5c8c895a1be001
)


2015-11-01 18:01:18
IP:71.11.172.143
Link:http://lessonsonthego.com/home/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636b5c8c895a1be002
)


2015-11-01 18:01:22
IP:71.11.172.143
Link:http://lessonsonthego.com/application/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636b5c8c895a1be003
)


2015-11-01 18:30:59
IP:66.249.79.228
Link:http://lessonsonthego.com/team_member/corey-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 18:55:58
IP:207.46.13.30
Link:http://lessonsonthego.com/team-member/kaylan-b/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 19:00:51
IP:66.249.79.235
Link:http://lessonsonthego.com/uncategorized/programs-groups/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 19:02:35
IP:66.249.79.221
Link:http://lessonsonthego.com/tutoring/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 19:17:10
IP:162.112.18.16
Link:http://lessonsonthego.com/music/violin-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636c778819a6953000
)


2015-11-01 19:17:25
IP:162.112.18.16
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636c778819a6953000
)


2015-11-01 19:18:42
IP:162.112.18.16
Link:http://lessonsonthego.com/programs/recitals/recital-registration/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636c778819a6953001
)


2015-11-01 19:19:16
IP:162.112.18.16
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636c778819a6953003
)


2015-11-01 19:21:25
IP:162.112.18.16
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636c84547e09432000
)


2015-11-01 19:29:34
IP:157.55.39.177
Link:http://lessonsonthego.com/2014/07/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 20:00:57
IP:207.46.13.30
Link:http://www.lessonsonthego.com/music/voice-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 20:01:50
IP:207.46.13.30
Link:http://lessonsonthego.com/music/voice-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 20:07:29
IP:73.44.184.31
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636d36640e47a71000
)


2015-11-01 20:07:34
IP:73.44.184.31
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636d33f02ac23f7002
)


2015-11-01 20:18:22
IP:66.249.79.235
Link:http://lessonsonthego.com/music-lessons-2/how-young-is-too-young/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 20:26:15
IP:66.249.79.220
Link:http://www.lessonsonthego.com/sitemap-pt-post-2015-01.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 20:29:19
IP:66.249.79.235
Link:http://lessonsonthego.com/wp-content/plugins/motopress-slider/motoslider_core/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 20:31:39
IP:175.100.147.36
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 20:51:56
IP:119.94.62.96
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636ddd9ca2d90bb000
)


2015-11-01 20:59:07
IP:66.249.79.235
Link:http://lessonsonthego.com/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:00:22
IP:68.180.228.97
Link:http://lessonsonthego.com/music/clarinet
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:00:23
IP:68.180.228.97
Link:http://lessonsonthego.com/music/clarinet/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:14:37
IP:100.43.90.10
Link:http://lessonsonthego.com/home/cancellation-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:16:34
IP:12.196.67.6
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:17:15
IP:73.22.92.96
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:34:09
IP:66.249.79.221
Link:http://lessonsonthego.com/music-lessons-2/the-best-keyboards-of-2015/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:37:26
IP:66.249.79.228
Link:http://lessonsonthego.com/team_member/chris-evans/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:39:04
IP:175.100.147.36
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=a8db0ddb-735b-4cb4-9f4a-e4975e7657fd&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => a8db0ddb-735b-4cb4-9f4a-e4975e7657fd
    [nocache] => 1
)


2015-11-01 21:39:39
IP:175.100.147.36
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
)


2015-11-01 21:41:36
IP:157.55.39.172
Link:http://lessonsonthego.com/testimonials/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:42:35
IP:103.57.173.123
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636e7eab12a384c000
)


2015-11-01 21:45:36
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 21:45:52
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636ea7401c3ba2d000
)


2015-11-01 21:45:58
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636ea7401c3ba2d001
)


2015-11-01 21:46:10
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636ea7401c3ba2d002
)


2015-11-01 21:46:18
IP:76.31.253.156
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636ea7401c3ba2d003
)


2015-11-01 21:46:18
IP:76.31.253.156
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636ea7401c3ba2d003
)


2015-11-01 21:46:46
IP:72.14.199.119
Link:http://lessonsonthego.com/music/piano-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:48:12
IP:178.255.215.74
Link:http://www.lessonsonthego.com/jobs-music-lessons-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:48:25
IP:178.255.215.74
Link:http://lessonsonthego.com/jobs-music-lessons-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 21:48:55
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636ea7401c3ba2d004
)


2015-11-01 21:53:34
IP:54.90.220.103
Link:http://lessonsonthego.com/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 22:08:40
IP:175.100.147.36
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 22:15:53
IP:72.14.199.113
Link:http://lessonsonthego.com/wp-content/uploads/2014/04/Sandra-G-element175.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 22:18:45
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636ea7401c3ba2d005
)


2015-11-01 22:19:29
IP:66.249.79.228
Link:http://lessonsonthego.com/sitemap-pt-post-2015-05.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 22:39:26
IP:175.100.147.36
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=dfd3441a-bc39-4df4-9daa-d39b1e088c6e&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => dfd3441a-bc39-4df4-9daa-d39b1e088c6e
    [nocache] => 1
    [__atuvs] => 5636f6bbb0797b29000
)


2015-11-01 22:44:07
IP:157.55.39.172
Link:http://www.lessonsonthego.com/Kollin-B.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 22:52:42
IP:175.100.147.36
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5636f6bbb0797b29000
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
)


2015-11-01 22:55:24
IP:207.46.13.30
Link:http://www.lessonsonthego.com/our-staff/testi/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 22:57:12
IP:207.46.13.30
Link:http://lessonsonthego.com/our-staff/testi/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:00:01
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 23:00:03
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 23:00:22
IP:76.31.253.156
Link:http://lessonsonthego.com/privacy-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636fbe76a0565bf000
)


2015-11-01 23:01:00
IP:69.30.198.186
Link:http://www.lessonsonthego.com/music/mandolin
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:31
IP:77.75.78.166
Link:http://lessonsonthego.com/wp-content/uploads/2014/04/wp_8v0xvwb9zx_000598.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:37
IP:77.75.78.166
Link:http://www.lessonsonthego.com/music/drum-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:43
IP:77.75.78.166
Link:http://lessonsonthego.com/programs/recitals/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:46
IP:77.75.78.166
Link:http://www.lessonsonthego.com/music/voice-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:49
IP:77.75.78.166
Link:http://lessonsonthego.com/music/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:51
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/david-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:53
IP:77.75.78.166
Link:http://www.lessonsonthego.com/wp-content/uploads/2013/10/temporary_zpse6df4f6c.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:56
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/kerry-h/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:09:59
IP:77.75.78.166
Link:http://lessonsonthego.com/music/bass-lessons/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:01
IP:77.75.78.166
Link:http://www.lessonsonthego.com/music/cello-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:04
IP:77.75.78.166
Link:http://lessonsonthego.com/blog/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:06
IP:77.75.78.166
Link:http://lessonsonthego.com/music/mandolin/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:08
IP:77.75.78.166
Link:http://www.lessonsonthego.com/sitemap-pt-post-2013-02.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:10
IP:77.75.78.166
Link:http://www.lessonsonthego.com/sitemap-pt-post-2012-05.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:11
IP:77.75.78.166
Link:http://www.lessonsonthego.com/sitemap-pt-post-2013-01.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:13
IP:77.75.78.166
Link:http://www.lessonsonthego.com/sitemap-pt-post-2013-03.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:21
IP:77.75.78.166
Link:http://lessonsonthego.com/application/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:31
IP:77.75.78.166
Link:http://lessonsonthego.com/tutors/science-tutors/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:33
IP:77.75.78.166
Link:http://www.lessonsonthego.com/wp-content/uploads/2014/05/thewoodlandstownshiplogo_10.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:36
IP:77.75.78.166
Link:http://lessonsonthego.com/music/music-theory/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:39
IP:77.75.78.166
Link:http://www.lessonsonthego.com/wp-content/uploads/2013/10/KerryHelement54.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:41
IP:77.75.78.166
Link:http://www.lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:44
IP:77.75.78.166
Link:http://www.lessonsonthego.com/sitemap-pt-page-2014-11.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:46
IP:77.75.78.166
Link:http://lessonsonthego.com/recital-ettiquette/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:49
IP:77.75.78.166
Link:http://lessonsonthego.com/music/guitar-teachers/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:51
IP:77.75.78.166
Link:http://www.lessonsonthego.com/tutors/math-tutoring/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:53
IP:77.75.78.166
Link:http://lessonsonthego.com/music/flute-lessons/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:56
IP:77.75.78.166
Link:http://www.lessonsonthego.com/wp-content/uploads/2014/04/Sandra-G-element175.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:10:59
IP:77.75.78.166
Link:http://lessonsonthego.com/home/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:01
IP:77.75.78.166
Link:http://lessonsonthego.com/how-to-test-prep/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:03
IP:77.75.78.166
Link:http://www.lessonsonthego.com/wp-content/uploads/2014/08/logowordpressheader2.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:06
IP:77.75.78.166
Link:http://www.lessonsonthego.com/sitemap-pt-post-2012-05.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:08
IP:77.75.78.166
Link:http://lessonsonthego.com/tutors/history/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:11
IP:77.75.78.166
Link:http://lessonsonthego.com/programs/recitals/commonly-asked-recital-questions/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:14
IP:77.75.78.166
Link:http://lessonsonthego.com/music/flute-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:19
IP:77.75.78.166
Link:http://lessonsonthego.com/violin-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:21
IP:77.75.78.166
Link:http://lessonsonthego.com/portfolio/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:23
IP:77.75.78.166
Link:http://lessonsonthego.com/how-to-test-prep/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:24
IP:77.75.78.166
Link:http://lessonsonthego.com/thank-you/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:28
IP:77.75.78.166
Link:http://lessonsonthego.com/how-young-is-too-young/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:43
IP:77.75.78.166
Link:http://lessonsonthego.com/sitemap.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:50
IP:77.75.78.166
Link:http://lessonsonthego.com/upper-level-math-tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:52
IP:77.75.78.166
Link:http://lessonsonthego.com/refund-referral-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:56
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/rachel-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:11:57
IP:77.75.78.166
Link:http://lessonsonthego.com/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:03
IP:77.75.78.166
Link:http://lessonsonthego.com/tutors/french-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:14
IP:77.75.78.166
Link:http://lessonsonthego.com/programs/recitals/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:16
IP:77.75.78.166
Link:http://lessonsonthego.com/home/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:19
IP:77.75.78.166
Link:http://lessonsonthego.com/how-much-tutoring-does-a-studnet-need/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:21
IP:77.75.78.166
Link:http://lessonsonthego.com/portfolio/services-2/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:22
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/sam-k/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:24
IP:77.75.78.166
Link:http://lessonsonthego.com/the-unexpected-benefits-of-french-tutoring-for-children/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:26
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/melanie-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:27
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/anthony-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:30
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/sandra-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:31
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/ana-a/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:34
IP:77.75.78.166
Link:http://lessonsonthego.com/team_member/lorrie-r/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:12:36
IP:77.75.78.166
Link:http://lessonsonthego.com/the-best-keyboards-of-2015/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:14:44
IP:207.46.13.30
Link:http://www.lessonsonthego.com/Dylan-T-.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:15:38
IP:54.147.167.81
Link:http://lessonsonthego.com/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:21:33
IP:216.69.183.60
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=a89728ac-33f5-4678-a02f-5adc56cbb9df&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => a89728ac-33f5-4678-a02f-5adc56cbb9df
    [nocache] => 1
)


2015-11-01 23:23:19
IP:216.69.183.60
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446618095|HDhDxTO3Q3RpV7XJ33HhYZSEVa9MuHG3QakYTbBmCFp|71cdfd88b28fbb09cb0eff34735b9693283d83b0d3d3ceb4dafc6b82b00795e9
    [PHPSESSID] => jarebjrmamr3lit6g23gtfehe0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446445295
)


2015-11-01 23:28:04
IP:66.249.79.228
Link:http://lessonsonthego.com/uncategorized/fusce-suscipit-varius/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:28:23
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636fbe76a0565bf001
)


2015-11-01 23:32:41
IP:216.69.183.60
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446618095|HDhDxTO3Q3RpV7XJ33HhYZSEVa9MuHG3QakYTbBmCFp|71cdfd88b28fbb09cb0eff34735b9693283d83b0d3d3ceb4dafc6b82b00795e9
    [PHPSESSID] => jarebjrmamr3lit6g23gtfehe0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446445295
    [__atuvs] => 5637015d53f22073000
)


2015-11-01 23:33:28
IP:180.76.15.12
Link:http://www.lessonsonthego.com/team_member/ana-a/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:35:28
IP:216.69.183.60
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446618095|HDhDxTO3Q3RpV7XJ33HhYZSEVa9MuHG3QakYTbBmCFp|71cdfd88b28fbb09cb0eff34735b9693283d83b0d3d3ceb4dafc6b82b00795e9
    [PHPSESSID] => jarebjrmamr3lit6g23gtfehe0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446445295
    [__atuvs] => 5637015d53f22073001
)


2015-11-01 23:36:52
IP:157.55.39.172
Link:http://www.lessonsonthego.com/Careers.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:37:04
IP:157.55.39.171
Link:http://www.lessonsonthego.com/careers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:38:11
IP:157.55.39.172
Link:http://lessonsonthego.com/careers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:46:48
IP:157.55.39.152
Link:http://www.lessonsonthego.com/BookIt.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:48:46
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_COMMAND=FLUSH_CACHE&GD_NONCE=1ce5f5d8c8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => FLUSH_CACHE
    [GD_NONCE] => 1ce5f5d8c8
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636fbe76a0565bf002
)


2015-11-01 23:48:48
IP:66.249.79.228
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-01 23:48:48
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_NONCE=1ce5f5d8c8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 1ce5f5d8c8
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636fbe76a0565bf002
)


2015-11-01 23:54:32
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_NONCE=1ce5f5d8c8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 1ce5f5d8c8
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5636fbe76a0565bf003
)


2015-11-02 00:05:43
IP:66.249.79.228
Link:http://lessonsonthego.com/music-lessons-2/top-5-guitars-for-the-beginning-guitarist/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 00:05:57
IP:74.125.63.33
Link:http://lessonsonthego.com/music/piano-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 00:19:53
IP:207.46.13.30
Link:http://www.lessonsonthego.com/sitemap-pt-page-2014-07.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 00:20:38
IP:157.55.39.176
Link:http://lessonsonthego.com/portfolio/services-3/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 00:30:58
IP:157.55.39.152
Link:http://www.lessonsonthego.com/tutors/math-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 00:33:11
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap-pt-nav_menu_item-2015-10.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 00:39:56
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=8d6a3dda-22e6-4268-b7e6-5e518c927716&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => 8d6a3dda-22e6-4268-b7e6-5e518c927716
    [nocache] => 1
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 00:42:11
IP:157.55.39.176
Link:http://www.lessonsonthego.com/Thomas-K.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 00:56:34
IP:66.249.79.228
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:09:01
IP:207.46.13.30
Link:http://www.lessonsonthego.com/sitemap-pt-wpcf7_contact_form-2014-11.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:21:30
IP:66.249.79.221
Link:http://lessonsonthego.com/music-lessons-2/what-do-i-need-prepared-for-a-music-lesson/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:24:18
IP:141.8.143.176
Link:http://lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:40:43
IP:157.55.39.160
Link:http://www.lessonsonthego.com/sitemap-pt-team-member-2014-08.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:49:27
IP:66.249.79.228
Link:http://lessonsonthego.com/our-staff/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:57:11
IP:66.249.79.235
Link:http://lessonsonthego.com/sitemap-pt-page-2015-05.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:57:21
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-content/plugins/formcraft/file-upload/server/php/upload.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 01:57:24
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-content/plugins/revslider/temp/update_extract/revslider/db.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 01:57:26
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-content/uploads/wpallimport/uploads/ba0554a46c3c814f5120939465287bc3/db.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 01:57:28
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-content/plugins/wp-symposium/server/php/index.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [uploader_url] => http://www.lessonsonthego.com/wp-content/plugins/wp-symposium/server/php/
    [uploader_uid] => 1
    [uploader_dir] => ./eoTMpJ
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 01:57:29
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-content/plugins/wp-symposium/server/php/eoTMpJsyCDmCeE.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 01:57:29
IP:82.146.36.221
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [action] => wpdm_ajax_call
    [user_login] => rootuser
    [execute] => wp_insert_user
    [role] => administrator
    [user_pass] => gimboroot
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 01:57:31
IP:82.146.36.221
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [action] => wpmp_pp_ajax_call
    [user_login] => wproot
    [execute] => wp_insert_user
    [role] => administrator
    [user_pass] => rootwp
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 02:16:57
IP:66.249.79.221
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 02:19:17
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap-pt-team_member-2015-09.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 02:26:17
IP:66.249.79.221
Link:http://lessonsonthego.com/programs/recitals/recital-registration/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 02:29:26
IP:66.249.79.221
Link:http://lessonsonthego.com/violin-pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 02:33:21
IP:66.249.79.228
Link:http://lessonsonthego.com/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 02:37:17
IP:66.249.79.221
Link:http://lessonsonthego.com/tutoring/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 02:55:04
IP:175.100.147.23
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=dd1d0d65-d2f7-4ec8-a5dd-7778cf79557a&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => dd1d0d65-d2f7-4ec8-a5dd-7778cf79557a
    [nocache] => 1
    [__atuvs] => 56373273b0591d51000
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-02 02:56:42
IP:157.55.39.160
Link:http://lessonsonthego.com/cancellation-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 02:58:45
IP:175.100.147.23
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56373273b0591d51000
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
)


2015-11-02 03:02:09
IP:175.100.147.23
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvs] => 56373273b0591d51001
)


2015-11-02 03:02:20
IP:175.100.147.23
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
)


2015-11-02 03:03:33
IP:175.100.147.23
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvs] => 563734b189bc40d6000
)


2015-11-02 03:04:57
IP:175.100.147.23
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvs] => 56373273b0591d51002
)


2015-11-02 03:05:06
IP:175.100.147.23
Link:http://lessonsonthego.com/?GD_COMMAND=FLUSH_CACHE&GD_NONCE=cc95762c5d
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => FLUSH_CACHE
    [GD_NONCE] => cc95762c5d
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvs] => 56373273b0591d51003
)


2015-11-02 03:05:07
IP:175.100.147.23
Link:http://lessonsonthego.com/?GD_COMMAND=FLUSH_CACHE&GD_NONCE=cc95762c5d
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => FLUSH_CACHE
    [GD_NONCE] => cc95762c5d
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvs] => 56373273b0591d51003
)


2015-11-02 03:05:09
IP:175.100.147.23
Link:http://lessonsonthego.com/?GD_NONCE=cc95762c5d
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => cc95762c5d
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
    [__atuvs] => 56373273b0591d51003
)


2015-11-02 03:11:21
IP:66.249.74.102
Link:http://www.lessonsonthego.com/sitemap-pt-page-2015-10.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:16:52
IP:141.8.143.176
Link:http://lessonsonthego.com/programs/recitals/practicing-for-a-recital/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:31:07
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=843ad0e3-3b12-4f87-b412-f9f724bb2b82&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => 843ad0e3-3b12-4f87-b412-f9f724bb2b82
    [nocache] => 1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-02 03:31:08
IP:66.249.79.220
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:31:21
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
)


2015-11-02 03:31:44
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_COMMAND=FLUSH_CACHE&GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => FLUSH_CACHE
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c000
)


2015-11-02 03:31:46
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c000
)


2015-11-02 03:32:16
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c001
)


2015-11-02 03:32:18
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c001
)


2015-11-02 03:36:10
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c002
)


2015-11-02 03:36:11
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c002
)


2015-11-02 03:40:17
IP:66.249.79.221
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:41:31
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c003
)


2015-11-02 03:41:33
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c003
)


2015-11-02 03:42:31
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c004
)


2015-11-02 03:42:33
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c004
)


2015-11-02 03:44:03
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c005
)


2015-11-02 03:44:05
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c005
)


2015-11-02 03:44:47
IP:66.249.79.221
Link:http://lessonsonthego.com/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:48:37
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c006
)


2015-11-02 03:48:39
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c006
)


2015-11-02 03:53:04
IP:66.249.79.221
Link:http://lessonsonthego.com/category/music-lessons-2/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:54:26
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c007
)


2015-11-02 03:54:27
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c007
)


2015-11-02 03:55:22
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c008
)


2015-11-02 03:55:24
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c008
)


2015-11-02 03:55:29
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c009
)


2015-11-02 03:56:38
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7&GD_COMMAND=FLUSH_CACHE
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [GD_COMMAND] => FLUSH_CACHE
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00a
)


2015-11-02 03:56:39
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00a
)


2015-11-02 03:58:52
IP:175.100.147.115
Link:http://www.lessonsonthego.com/favicon.ico
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:58:56
IP:157.55.39.176
Link:http://lessonsonthego.com/music/violin-teacher
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 03:59:26
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00b
)


2015-11-02 03:59:52
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00c
)


2015-11-02 04:00:05
IP:175.100.147.115
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:00:06
IP:175.100.147.115
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:00:31
IP:175.100.147.115
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:00:59
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00d
)


2015-11-02 04:02:22
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00e
)


2015-11-02 04:02:28
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_COMMAND=FLUSH_CACHE&GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => FLUSH_CACHE
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00f
)


2015-11-02 04:02:30
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_NONCE=5b860c70f7
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 5b860c70f7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c00f
)


2015-11-02 04:03:28
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c010
)


2015-11-02 04:04:47
IP:66.249.74.100
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:04:48
IP:66.249.79.221
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:07:46
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:47
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:48
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:49
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:50
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:51
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:52
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:53
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:07:54
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:08:44
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56373b7cc6e7bc1c011
)


2015-11-02 04:12:54
IP:141.8.143.176
Link:http://lessonsonthego.com/oldindex1/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:17:34
IP:66.249.74.102
Link:http://www.lessonsonthego.com/sitemap-pt-page-2015-08.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:34:43
IP:69.30.198.202
Link:http://www.lessonsonthego.com/music/piano-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:35:02
IP:69.30.198.202
Link:http://www.lessonsonthego.com/music/vocal-coaches
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:35:05
IP:69.30.198.202
Link:http://lessonsonthego.com/music/vocal-coaches
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:35:08
IP:69.30.198.202
Link:http://www.lessonsonthego.com/tutors/biology
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:42:49
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
)


2015-11-02 04:43:37
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap-pt-page-2015-07.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 04:45:39
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56374c3ade5c1ccc000
)


2015-11-02 04:48:07
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56374c3ade5c1ccc001
)


2015-11-02 04:51:30
IP:175.100.147.115
Link:http://lessonsonthego.com/music/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvs] => 56374c3ade5c1ccc002
)


2015-11-02 05:02:29
IP:157.55.39.153
Link:http://www.lessonsonthego.com/Spanish-Tutors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:02:48
IP:175.100.147.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 56374c3ade5c1ccc002
)


2015-11-02 05:03:39
IP:175.100.147.115
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=ceaca6cb-3e25-460f-897e-f8e1d7ecab68&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => ceaca6cb-3e25-460f-897e-f8e1d7ecab68
    [nocache] => 1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 56374c3ade5c1ccc003
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-02 05:04:12
IP:66.249.79.221
Link:http://lessonsonthego.com/testimonial-view/testimonial-6/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:08:51
IP:66.249.79.228
Link:http://lessonsonthego.com/tutoring/how-much-tutoring-does-a-studnet-need/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:13:02
IP:175.100.147.115
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 56374c3ade5c1ccc003
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|7ffc8d94214f85062e77093312b79b7997db399775b732f706d5eef7bec9edfa
)


2015-11-02 05:13:38
IP:175.100.147.115
Link:http://lessonsonthego.com/tutors/?GD_COMMAND=FLUSH_CACHE&GD_NONCE=9954924611
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => FLUSH_CACHE
    [GD_NONCE] => 9954924611
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|7ffc8d94214f85062e77093312b79b7997db399775b732f706d5eef7bec9edfa
    [__atuvs] => 56374c3ade5c1ccc004
)


2015-11-02 05:13:40
IP:175.100.147.115
Link:http://lessonsonthego.com/tutors/?GD_NONCE=9954924611
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 9954924611
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|7ffc8d94214f85062e77093312b79b7997db399775b732f706d5eef7bec9edfa
    [__atuvs] => 56374c3ade5c1ccc004
)


2015-11-02 05:26:30
IP:66.87.121.246
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56375663d8da5068000
)


2015-11-02 05:26:31
IP:66.87.121.246
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56375663d8da5068000
)


2015-11-02 05:26:55
IP:66.87.121.246
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:26:57
IP:66.87.121.246
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:27:25
IP:66.87.121.246
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56375691f26702b4000
)


2015-11-02 05:45:54
IP:178.235.13.172
Link:http://lessonsonthego.com/wp-content/plugins/google-document-embedder/css/admin-styles.css
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:48:25
IP:141.8.143.176
Link:http://lessonsonthego.com/music-lessons-2/top-5-guitars-for-the-beginning-guitarist/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:50:32
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:51:06
IP:157.55.39.240
Link:http://lessonsonthego.com/the-best-keyboards-of-2015/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:53:05
IP:66.249.79.235
Link:http://lessonsonthego.com/sitemap-archives.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:56:29
IP:207.46.13.30
Link:http://www.lessonsonthego.com/testimonials.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 05:56:30
IP:207.46.13.30
Link:http://www.lessonsonthego.com/Pre-cal--Calculas.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:01
IP:69.30.211.2
Link:http://lessonsonthego.com/music-lessons-2/how-young-is-too-young/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:03
IP:69.30.211.2
Link:http://lessonsonthego.com/music-lessons-2/jobs-music-lessons-company/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:04
IP:69.30.211.2
Link:http://lessonsonthego.com/music-lessons-2/the-best-keyboards-of-2015/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:06
IP:69.30.211.2
Link:http://lessonsonthego.com/music-lessons-2/what-do-i-need-prepared-for-a-music-lesson/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:08
IP:69.30.211.2
Link:http://lessonsonthego.com/tutoring/apply-to-work-for-a-tutoring-company/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:10
IP:69.30.211.2
Link:http://lessonsonthego.com/tutoring/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:11
IP:69.30.211.2
Link:http://lessonsonthego.com/tutoring/how-much-tutoring-does-a-studnet-need/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:03:13
IP:69.30.211.2
Link:http://lessonsonthego.com/tutoring/how-to-test-prep/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:23:11
IP:66.249.79.221
Link:http://lessonsonthego.com/maintenance/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:24:38
IP:66.249.79.228
Link:http://lessonsonthego.com/category/music-lessons-2/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:37:01
IP:207.46.13.141
Link:http://lessonsonthego.com/category/tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:37:03
IP:207.46.13.141
Link:http://lessonsonthego.com/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:37:04
IP:207.46.13.141
Link:http://lessonsonthego.com/team_member/skyler-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:37:06
IP:207.46.13.141
Link:http://lessonsonthego.com/team_member/mike-f/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:37:07
IP:207.46.13.141
Link:http://lessonsonthego.com/sitemap-pt-page-2015-10.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:38:36
IP:73.22.92.96
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:38:52
IP:73.22.92.96
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 563767532d37031d000
)


2015-11-02 06:42:14
IP:157.55.39.152
Link:http://lessonsonthego.com/2014/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:42:16
IP:157.55.39.152
Link:http://lessonsonthego.com/sitemap-pt-page-2013-10.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:42:18
IP:157.55.39.152
Link:http://lessonsonthego.com/portfolio/services-4/page/2/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:50:54
IP:72.14.199.119
Link:http://lessonsonthego.com/wp-content/uploads/2014/04/Sandra-G-element175.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:15
IP:67.212.188.154
Link:http://lessonsonthego.com/th1s_1s_a_4o4.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:18
IP:67.212.188.154
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:21
IP:67.212.188.154
Link:http://lessonsonthego.com/?=Search&s=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [s] => 1
)


2015-11-02 06:53:23
IP:67.212.188.154
Link:http://lessonsonthego.com/music/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:26
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:28
IP:67.212.188.154
Link:http://lessonsonthego.com/privacy-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:33
IP:67.212.188.154
Link:http://lessonsonthego.com/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:33
IP:67.212.188.154
Link:http://lessonsonthego.com/refund-referral-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:36
IP:67.212.188.154
Link:http://lessonsonthego.com/?p=2
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 2
)


2015-11-02 06:53:37
IP:67.212.188.154
Link:http://lessonsonthego.com/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:38
IP:67.212.188.154
Link:http://lessonsonthego.com/blog/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:40
IP:67.212.188.154
Link:http://lessonsonthego.com/?p=47
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 47
)


2015-11-02 06:53:40
IP:67.212.188.154
Link:http://lessonsonthego.com/?p=1998
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 1998
)


2015-11-02 06:53:41
IP:67.212.188.154
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:42
IP:67.212.188.154
Link:http://lessonsonthego.com/testimonials/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:43
IP:67.212.188.154
Link:http://lessonsonthego.com/?p=3201
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 3201
)


2015-11-02 06:53:44
IP:67.212.188.154
Link:http://lessonsonthego.com/?p=169
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 169
)


2015-11-02 06:53:44
IP:67.212.188.154
Link:http://lessonsonthego.com/music/song-writing
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:45
IP:67.212.188.154
Link:http://lessonsonthego.com/music/song-writing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:47
IP:67.212.188.154
Link:http://lessonsonthego.com/how-much-tutoring-does-a-studnet-need/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:48
IP:67.212.188.154
Link:http://lessonsonthego.com/application/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:50
IP:67.212.188.154
Link:http://lessonsonthego.com/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:51
IP:67.212.188.154
Link:http://lessonsonthego.com/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:52
IP:67.212.188.154
Link:http://lessonsonthego.com/contactus/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:54
IP:67.212.188.154
Link:http://lessonsonthego.com/violin-pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:55
IP:67.212.188.154
Link:http://lessonsonthego.com/viola-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:56
IP:67.212.188.154
Link:http://lessonsonthego.com/testimonials/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:56
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:53:58
IP:67.212.188.154
Link:http://lessonsonthego.com/music-lessons-2/top-5-guitars-for-the-beginning-guitarist/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:00
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/physics/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:01
IP:67.212.188.154
Link:http://lessonsonthego.com/music-lessons-2/jobs-music-lessons-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:03
IP:67.212.188.154
Link:http://lessonsonthego.com/music-lessons-2/how-young-is-too-young/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:06
IP:67.212.188.154
Link:http://lessonsonthego.com/home/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:07
IP:67.212.188.154
Link:http://lessonsonthego.com/tutoring/the-unexpected-benefits-of-french-tutoring-for-children/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:08
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:11
IP:67.212.188.154
Link:http://lessonsonthego.com/music/flute-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:12
IP:67.212.188.154
Link:http://lessonsonthego.com/music/flute-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:13
IP:67.212.188.154
Link:http://lessonsonthego.com/music/bass-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:15
IP:67.212.188.154
Link:http://lessonsonthego.com/music/bass-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:16
IP:67.212.188.154
Link:http://lessonsonthego.com/music-lessons-2/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:18
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/math-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:21
IP:67.212.188.154
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:22
IP:67.212.188.154
Link:http://lessonsonthego.com/music/banjo-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:24
IP:67.212.188.154
Link:http://lessonsonthego.com/tutoring/apply-to-work-for-a-tutoring-company/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:26
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/history/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:27
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/chris-evans/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:29
IP:67.212.188.154
Link:http://lessonsonthego.com/music/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:30
IP:67.212.188.154
Link:http://lessonsonthego.com/music/music-theory/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:32
IP:67.212.188.154
Link:http://lessonsonthego.com/comments/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:32
IP:67.212.188.154
Link:http://lessonsonthego.com/music/saxophone-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:34
IP:67.212.188.154
Link:http://lessonsonthego.com/tutoring/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:35
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/spanish-teachers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:39
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/spanish-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:40
IP:67.212.188.154
Link:http://lessonsonthego.com/testimonial-view/katherine-f/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:42
IP:67.212.188.154
Link:http://lessonsonthego.com/home/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:42
IP:67.212.188.154
Link:http://lessonsonthego.com/category/music-lessons-2/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:45
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/eric-b/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:46
IP:67.212.188.154
Link:http://lessonsonthego.com/testimonial-view/rebecca-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:48
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/lorrie-r/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:49
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/economics-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:51
IP:67.212.188.154
Link:http://lessonsonthego.com/contacts/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:51
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/sam-k/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:53
IP:67.212.188.154
Link:http://lessonsonthego.com/pricing/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:54
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/charles-d/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:55
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/cammy-d/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:56
IP:67.212.188.154
Link:http://lessonsonthego.com/category/blog/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:57
IP:67.212.188.154
Link:http://lessonsonthego.com/music/violin-lesson
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:58
IP:67.212.188.154
Link:http://lessonsonthego.com/music/violin-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:54:59
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/megan-l/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:01
IP:67.212.188.154
Link:http://lessonsonthego.com/programs/recitals/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:02
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/math-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:02
IP:67.212.188.154
Link:http://lessonsonthego.com/testimonial-view/becky-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:04
IP:67.212.188.154
Link:http://lessonsonthego.com/recital-etiquette/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:05
IP:67.212.188.154
Link:http://lessonsonthego.com/recital-registration/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:06
IP:67.212.188.154
Link:http://lessonsonthego.com/commonly-asked-recital-questions
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:07
IP:67.212.188.154
Link:http://lessonsonthego.com/practicing-for-a-recital/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:09
IP:67.212.188.154
Link:http://lessonsonthego.com/privacy-policy/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:09
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/heather-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:10
IP:67.212.188.154
Link:http://lessonsonthego.com/music/cello-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:11
IP:67.212.188.154
Link:http://lessonsonthego.com/music/cello-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:12
IP:67.212.188.154
Link:http://lessonsonthego.com/violin-pricing/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:13
IP:67.212.188.154
Link:http://lessonsonthego.com/team_member/linda-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:15
IP:67.212.188.154
Link:http://lessonsonthego.com/contactus/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:15
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/science-tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:17
IP:67.212.188.154
Link:http://lessonsonthego.com/home/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:19
IP:67.212.188.154
Link:http://lessonsonthego.com/tutoring/how-much-tutoring-does-a-studnet-need/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:20
IP:67.212.188.154
Link:http://lessonsonthego.com/music/clarinet
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:21
IP:67.212.188.154
Link:http://lessonsonthego.com/music/clarinet/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:23
IP:67.212.188.154
Link:http://lessonsonthego.com/category/tutor/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:24
IP:67.212.188.154
Link:http://lessonsonthego.com/refund-referral-policy/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:24
IP:67.212.188.154
Link:http://lessonsonthego.com/testimonial-view/sherrie-l/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:26
IP:67.212.188.154
Link:http://lessonsonthego.com/music-lessons-2/the-best-keyboards-of-2015/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:28
IP:67.212.188.154
Link:http://lessonsonthego.com/music/voice-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:28
IP:67.212.188.154
Link:http://lessonsonthego.com/music/voice-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:29
IP:67.212.188.154
Link:http://lessonsonthego.com/tutors/french-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:30
IP:67.212.188.154
Link:http://lessonsonthego.com/music/mandolin
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:31
IP:67.212.188.154
Link:http://lessonsonthego.com/music/mandolin/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 06:55:32
IP:67.212.188.154
Link:http://lessonsonthego.com/home/cancellation-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:09:45
IP:180.76.15.15
Link:http://www.lessonsonthego.com/History-Teachers.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:09:47
IP:180.76.15.15
Link:http://www.lessonsonthego.com/tutors/history/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:24:34
IP:157.55.39.121
Link:http://lessonsonthego.com/wp-content/uploads/2014/05/029100568a002dda1c0b4a24141be0d4-e1429049492802.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:30:29
IP:157.55.39.172
Link:http://www.lessonsonthego.com/Chemistry-Tutors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:31:33
IP:144.76.29.162
Link:http://lessonsonthego.com/music/drum-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:31:39
IP:144.76.29.162
Link:http://lessonsonthego.com/testimonial-view/becky-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:31:41
IP:144.76.29.162
Link:http://lessonsonthego.com/testimonial-view/katherine-f/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:40:25
IP:66.249.79.228
Link:http://lessonsonthego.com/music-lessons-2/jobs-music-lessons-company/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:49:44
IP:180.76.15.22
Link:http://www.lessonsonthego.com/Julie-C.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:49:46
IP:180.76.15.160
Link:http://www.lessonsonthego.com/team-member/julie-c/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 07:49:47
IP:180.76.15.137
Link:http://lessonsonthego.com/team_member/julie-c/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:06:31
IP:73.206.146.168
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56377bef03271bdd000
)


2015-11-02 08:06:36
IP:73.206.146.168
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:09:56
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_NONCE=1ce5f5d8c8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 1ce5f5d8c8
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 08:12:54
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_NONCE=1ce5f5d8c8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 1ce5f5d8c8
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 56377ccfb963b40b000
)


2015-11-02 08:17:08
IP:157.55.39.152
Link:http://www.lessonsonthego.com/Special-Needs.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:20:25
IP:141.8.143.176
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/LPCA_Green_Logo.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:21:17
IP:157.55.39.152
Link:http://lessonsonthego.com/Special-Needs.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:21:40
IP:66.249.74.100
Link:http://www.lessonsonthego.com/sitemap.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:30:32
IP:123.125.71.25
Link:http://www.lessonsonthego.com/https:/lessonsonthego.com/wp-content/uploads/2013/10/readingparis_moodb_2462393b.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:30:35
IP:123.125.71.44
Link:http://lessonsonthego.com/https:/lessonsonthego.com/wp-content/uploads/2013/10/readingparis_moodb_2462393b.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:41:07
IP:100.43.85.5
Link:http://lessonsonthego.com/music-lessons-2/the-best-keyboards-of-2015/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 08:56:12
IP:66.249.79.221
Link:http://lessonsonthego.com/tutoring/apply-to-work-for-a-tutoring-company/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:00:49
IP:66.249.79.221
Link:http://lessonsonthego.com/blog/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:00:57
IP:100.43.85.5
Link:http://lessonsonthego.com/wp-content/uploads/2013/10/temporary_zpse6df4f6c.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:15:27
IP:66.249.79.220
Link:http://www.lessonsonthego.com/sitemap-pt-team-member-2014-09.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:28:16
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_NONCE=1ce5f5d8c8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 1ce5f5d8c8
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 09:30:53
IP:66.249.74.102
Link:http://www.lessonsonthego.com/sitemap-pt-page-2011-09.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:32:09
IP:175.100.147.49
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => v4ibe0134i8cj9bv3cgvvo5db2
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446630905|Ip3EKfhrF12R8uXyed1ulbQ0P3vUO2qNnDFdVLrQz9f|dcfaeb2e7e652f0b52dd1c51d3122cff7dd388811d625539e722297ffbd78cc4
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446458106
)


2015-11-02 09:33:27
IP:76.31.253.156
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => unonu76b0dvn36tj56nr382db4
)


2015-11-02 09:33:31
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 56378f2445aa91fa000
)


2015-11-02 09:36:33
IP:100.43.85.5
Link:http://lessonsonthego.com/music-lessons-2/how-young-is-too-young/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:39:25
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 56378f2445aa91fa001
)


2015-11-02 09:40:20
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=b3d9e21c-a2cc-413b-a2a4-4804053532b4&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => b3d9e21c-a2cc-413b-a2a4-4804053532b4
    [nocache] => 1
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 56378f2445aa91fa002
)


2015-11-02 09:53:06
IP:141.8.143.176
Link:http://lessonsonthego.com/tutoring/the-unexpected-benefits-of-french-tutoring-for-children/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:56:21
IP:64.202.160.161
Link:http://lessonsonthego.com/tutors/physics/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c000
)


2015-11-02 09:56:26
IP:64.202.160.161
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c001
)


2015-11-02 09:56:28
IP:64.202.160.161
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:56:34
IP:64.202.160.161
Link:http://lessonsonthego.com/tutors/history/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c002
)


2015-11-02 09:57:49
IP:64.202.160.161
Link:http://lessonsonthego.com/wp-contact/themes/theme54799/dial.css
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 09:58:24
IP:64.202.160.161
Link:http://lessonsonthego.com/wp-content/themes/theme54799/dial.css
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:00:18
IP:62.210.246.137
Link:http://lessonsonthego.com/music/voice-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:00:22
IP:62.210.246.137
Link:http://lessonsonthego.com/tutors/english-writing-tutoring/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:00:26
IP:62.210.246.137
Link:http://lessonsonthego.com/tutors/french-tutoring/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:00:31
IP:62.210.246.137
Link:http://lessonsonthego.com/tutors/science-tutors/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:00:43
IP:62.210.246.137
Link:http://lessonsonthego.com/tutors/spanish-teachers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:06:25
IP:180.76.15.157
Link:http://www.lessonsonthego.com/music/voice-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:07:16
IP:66.249.79.228
Link:http://lessonsonthego.com/violin-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:07:34
IP:158.135.201.49
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:07:34
IP:158.135.201.49
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f000
)


2015-11-02 10:08:00
IP:158.135.201.49
Link:http://lessonsonthego.com/team_member/stefan-m/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f001
)


2015-11-02 10:08:04
IP:158.135.201.49
Link:http://lessonsonthego.com/team_member/stefan-m/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f002
)


2015-11-02 10:08:45
IP:158.135.201.49
Link:http://lessonsonthego.com/team_member/sam-k/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f004
)


2015-11-02 10:08:51
IP:64.202.160.161
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c003
)


2015-11-02 10:08:52
IP:64.202.160.161
Link:http://lessonsonthego.com/programs/recitals/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c003
)


2015-11-02 10:08:59
IP:64.202.160.161
Link:http://lessonsonthego.com/programs/recitals/practicing-for-a-recital/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c005
)


2015-11-02 10:09:15
IP:64.202.160.161
Link:http://lessonsonthego.com/tutors/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c006
)


2015-11-02 10:09:25
IP:158.135.201.49
Link:http://lessonsonthego.com/team_member/chris-evans/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f006
)


2015-11-02 10:09:58
IP:158.135.201.49
Link:http://lessonsonthego.com/team_member/anthony-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f008
)


2015-11-02 10:10:05
IP:64.202.160.161
Link:http://lessonsonthego.com/music/cello-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c007
)


2015-11-02 10:10:10
IP:64.202.160.161
Link:http://lessonsonthego.com/tutors/math-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c008
)


2015-11-02 10:10:13
IP:64.202.160.161
Link:http://lessonsonthego.com/programs/recitals/commonly-asked-recital-questions/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379580952a1f5c009
)


2015-11-02 10:11:07
IP:158.135.201.49
Link:http://lessonsonthego.com/team_member/tyler-l/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f00a
)


2015-11-02 10:11:46
IP:158.135.201.49
Link:http://lessonsonthego.com/team_member/corey-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f00c
)


2015-11-02 10:14:33
IP:158.135.201.49
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56379854384aed7f00f
)


2015-11-02 10:19:35
IP:66.249.79.235
Link:http://lessonsonthego.com/music/guitar-teachers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:19:36
IP:66.249.79.228
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:36:25
IP:180.76.15.27
Link:http://www.lessonsonthego.com/recital-etiquette/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:36:29
IP:180.76.15.138
Link:http://lessonsonthego.com/recital-etiquette/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:38:10
IP:141.8.143.176
Link:http://lessonsonthego.com/blog/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:44:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:44:33
IP:76.31.253.156
Link:http://lessonsonthego.com/team_member/corey-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637a0f787f6bccd000
)


2015-11-02 10:51:42
IP:141.8.143.176
Link:http://lessonsonthego.com/tutoring/how-to-test-prep/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 10:52:15
IP:66.249.79.228
Link:http://lessonsonthego.com/apple-app-site-association
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:04:27
IP:141.8.143.176
Link:http://lessonsonthego.com/contacts/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:05:36
IP:66.249.79.213
Link:http://www.lessonsonthego.com/sitemap-pt-page-2015-04.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:16:32
IP:141.8.143.176
Link:http://lessonsonthego.com/tutoring/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:27:59
IP:141.8.143.176
Link:http://lessonsonthego.com/home/cancellation-policy/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:32:46
IP:157.55.39.240
Link:http://lessonsonthego.com/tim-f.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:34:46
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_COMMAND=SSO_LOGIN&SSO_HASH=5a6c6fa1-ea52-4f3f-b27e-d1eb322b3bd9&nocache=1
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_COMMAND] => SSO_LOGIN
    [SSO_HASH] => 5a6c6fa1-ea52-4f3f-b27e-d1eb322b3bd9
    [nocache] => 1
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 11:35:28
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 11:35:29
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 11:38:14
IP:66.249.79.221
Link:http://lessonsonthego.com/tutors/history/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:38:46
IP:141.8.143.176
Link:http://lessonsonthego.com/category/tutor/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:46:11
IP:109.149.178.174
Link:http://lessonsonthego.com/music/music-theory/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:46:14
IP:109.149.178.174
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 11:58:32
IP:141.8.143.176
Link:http://lessonsonthego.com/contactus/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:05:06
IP:99.101.201.147
Link:http://www.lessonsonthego.com/programs/recitals/recital-registration/?+Clients&utm_term=0_8b9760a0a9-3f3bd8adb2-121997929
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [Clients] => 
    [utm_term] => 0_8b9760a0a9-3f3bd8adb2-121997929
)


2015-11-02 12:05:08
IP:99.101.201.147
Link:http://lessonsonthego.com/programs/recitals/recital-registration/?+Clients&utm_term=0_8b9760a0a9-3f3bd8adb2-121997929
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [Clients] => 
    [utm_term] => 0_8b9760a0a9-3f3bd8adb2-121997929
)


2015-11-02 12:07:32
IP:141.8.143.176
Link:http://lessonsonthego.com/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:15:55
IP:141.8.143.176
Link:http://lessonsonthego.com/home/careers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:16:44
IP:123.125.71.18
Link:http://lessonsonthego.com/testimonial-view/rebecca-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:20:46
IP:123.125.71.72
Link:http://lessonsonthego.com/blog/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:23:03
IP:220.181.108.91
Link:http://lessonsonthego.com/music
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:23:45
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio_tag/alias/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:31:00
IP:141.8.143.176
Link:http://lessonsonthego.com/blog/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:37:41
IP:141.8.143.176
Link:http://lessonsonthego.com/contacts/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:37:53
IP:74.7.26.237
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637bb818f816e4c000
)


2015-11-02 12:38:41
IP:74.7.26.237
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637bb818f816e4c001
)


2015-11-02 12:38:46
IP:74.7.26.237
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:38:56
IP:74.7.26.237
Link:http://lessonsonthego.com/team_member/corey-s/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637bb818f816e4c002
)


2015-11-02 12:43:46
IP:141.8.143.176
Link:http://lessonsonthego.com/the-unexpected-benefits-of-french-tutoring-for-children/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:49:18
IP:141.8.143.176
Link:http://lessonsonthego.com/home/cancellation-policy/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:54:12
IP:141.8.143.176
Link:http://lessonsonthego.com/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:54:24
IP:66.249.79.228
Link:http://lessonsonthego.com/top-5-guitars-for-the-beginning-guitarist/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 12:58:31
IP:141.8.143.176
Link:http://lessonsonthego.com/home/careers/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:00:42
IP:76.31.253.156
Link:http://lessonsonthego.com/?GD_NONCE=1ce5f5d8c8
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [GD_NONCE] => 1ce5f5d8c8
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 13:00:48
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvs] => 5637c0eede33fb5d000
)


2015-11-02 13:02:09
IP:141.8.143.176
Link:http://lessonsonthego.com/what-do-i-need-prepared-for-a-music-lesson/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:03:30
IP:100.43.90.8
Link:http://lessonsonthego.com/bring-out-the-best-in-your-scholars-with-personalized-in-home-tutoring/contactus
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:04:04
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/gallery-format/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:05:05
IP:141.8.143.176
Link:http://lessonsonthego.com/how-much-tutoring-does-a-studnet-need/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:05:09
IP:207.46.13.141
Link:http://www.lessonsonthego.com/sitemap-pt-wpcf7_contact_form-2014-09.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:06:25
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/video-format/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:06:58
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio/services-3/category-1/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:07:48
IP:66.249.79.221
Link:http://lessonsonthego.com/portfolio-archive/video-format/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:19:05
IP:188.165.15.148
Link:http://lessonsonthego.com/music/cello-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:21:21
IP:52.91.143.41
Link:http://lessonsonthego.com/wp-content/themes/theme47407/bootstrap/css/bootstrap.css
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:32:08
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio/services-3/category-3/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:33:41
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637c65bcdbfc683000
)


2015-11-02 13:34:31
IP:141.8.143.176
Link:http://lessonsonthego.com/top-5-guitars-for-the-beginning-guitarist/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:40:40
IP:71.72.241.244
Link:http://lessonsonthego.com/music/drum-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:40:45
IP:71.72.241.244
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:43:17
IP:180.76.15.12
Link:http://www.lessonsonthego.com/home/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 13:56:29
IP:157.55.39.172
Link:http://www.lessonsonthego.com/MarieE.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:00:09
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio/services-3/category-3/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:00:26
IP:157.55.39.176
Link:http://www.lessonsonthego.com/Drum-Instructors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:00:48
IP:207.46.13.30
Link:http://www.lessonsonthego.com/sitemap-pt-team-member-2014-11.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:19:44
IP:157.55.39.70
Link:http://www.lessonsonthego.com/sitemap-pt-post-2014-12.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:24:02
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio-archive/suspendisse-arcu-nisl/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:26:24
IP:66.249.79.228
Link:http://lessonsonthego.com/what-do-i-need-prepared-for-a-music-lesson/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:29:49
IP:73.42.183.134
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:31:10
IP:66.249.79.220
Link:http://www.lessonsonthego.com/sitemap-pt-slider-2014-09.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:31:38
IP:73.42.183.134
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637d5ca600b1cfb000
)


2015-11-02 14:33:15
IP:66.249.79.213
Link:http://www.lessonsonthego.com/sitemap-pt-page-2015-03.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:41:35
IP:66.249.79.228
Link:http://lessonsonthego.com/uncategorized/fusce-suscipit-varius/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:41:37
IP:66.249.79.227
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 14:46:03
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio-archive/malesuada-fames-ac/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:06:07
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio-archive/feugiat-vitae-leo/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:08:43
IP:180.76.15.159
Link:http://www.lessonsonthego.com/French.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:08:44
IP:180.76.15.9
Link:http://www.lessonsonthego.com/tutors/french-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:12:38
IP:157.55.39.70
Link:http://lessonsonthego.com/how-to-test-prep/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:13:42
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap-pt-page-2015-03.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:23:37
IP:157.55.39.240
Link:http://lessonsonthego.com/team_member/heather-g/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:24:11
IP:141.8.143.176
Link:http://lessonsonthego.com/our-staff/archives/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:28:35
IP:76.31.253.156
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-02 15:29:24
IP:66.87.120.84
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637e3b353e0e4a7000
)


2015-11-02 15:30:31
IP:66.87.120.84
Link:http://lessonsonthego.com/home/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5637e3b353e0e4a7002
)


2015-11-02 15:40:01
IP:141.8.143.176
Link:http://lessonsonthego.com/programs/legacy-pca/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:45:32
IP:142.4.214.124
Link:http://lessonsonthego.com/home/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:49:13
IP:157.55.39.69
Link:http://lessonsonthego.com/tutors/math-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:53:22
IP:141.8.143.176
Link:http://lessonsonthego.com/portfolio-archive/feugiat-vitae-leo/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:56:14
IP:141.8.143.176
Link:http://lessonsonthego.com/testimonial-view/sherri-l-mother-and-woodforest-resident/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 15:58:40
IP:72.14.199.119
Link:http://lessonsonthego.com/music/piano-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:09:17
IP:157.55.39.69
Link:http://www.lessonsonthego.com/Privacy-Policy.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:11:16
IP:188.165.15.148
Link:http://lessonsonthego.com/music/cello-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:29:04
IP:99.172.33.222
Link:http://lessonsonthego.com/wp-content/uploads/2014/04/Sandra-G-element175.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:32:23
IP:207.46.13.30
Link:http://www.lessonsonthego.com/Josh-G.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:46:50
IP:157.55.39.152
Link:http://www.lessonsonthego.com/team-view/joey-c/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:46:52
IP:157.55.39.152
Link:http://www.lessonsonthego.com/Economics-Tutors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:46:54
IP:157.55.39.152
Link:http://www.lessonsonthego.com/sitemap-pt-faq-2014-09.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 16:46:55
IP:157.55.39.152
Link:http://www.lessonsonthego.com/tutors/economics-tutoring/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 17:44:57
IP:5.104.241.187
Link:http://www.lessonsonthego.com/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:07:27
IP:180.76.15.23
Link:http://www.lessonsonthego.com/?p=3201
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [p] => 3201
)


2015-11-02 18:07:30
IP:180.76.15.138
Link:http://lessonsonthego.com/refund-referral-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:08:08
IP:176.97.116.136
Link:http://lessonsonthego.com/wp-content/plugins/wp-powerplaygallery/readme.txt
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:11:24
IP:207.46.13.141
Link:http://www.lessonsonthego.com/sitemap-pt-nav_menu_item-2014-11.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:36:40
IP:157.55.39.160
Link:http://www.lessonsonthego.com/team-member/kaylan-b/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:40:57
IP:108.235.58.9
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:42:43
IP:158.69.209.141
Link:http://lessonsonthego.com/careers/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:42:47
IP:158.69.209.141
Link:http://lessonsonthego.com/careers/contactus
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:42:49
IP:158.69.209.141
Link:http://lessonsonthego.com/contactus/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:42:50
IP:108.235.58.9
Link:http://lessonsonthego.com/home/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 563810ab0360af27000
)


2015-11-02 18:42:52
IP:158.69.209.141
Link:http://lessonsonthego.com/music/contactus
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:42:59
IP:158.69.209.141
Link:http://lessonsonthego.com/music/flute-lessons/contacts
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:02
IP:158.69.209.141
Link:http://lessonsonthego.com/music/flute-lessons/contactus
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:06
IP:158.69.209.141
Link:http://lessonsonthego.com/music/saxophone-lessons/contactus
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:26
IP:158.69.209.141
Link:http://www.lessonsonthego.com/category/blog/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:30
IP:158.69.209.141
Link:http://lessonsonthego.com/category/blog/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:32
IP:158.69.209.141
Link:http://www.lessonsonthego.com/contactus
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:37
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/banjo-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:41
IP:158.69.209.141
Link:http://lessonsonthego.com/music/banjo-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:43
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/clarinet-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:48
IP:158.69.209.141
Link:http://lessonsonthego.com/music/clarinet-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:50
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/drum-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:57
IP:158.69.209.141
Link:http://lessonsonthego.com/music/drum-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:43:59
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/flute-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:04
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/guitar-teachers
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:10
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/mandolin-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:12
IP:108.235.58.9
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 563810ab0360af27001
)


2015-11-02 18:44:13
IP:158.69.209.141
Link:http://lessonsonthego.com/music/mandolin-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:15
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/music-theory
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:16
IP:108.235.58.9
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:19
IP:158.69.209.141
Link:http://lessonsonthego.com/music/music-theory/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:22
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/saxophone-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:26
IP:158.69.209.141
Link:http://lessonsonthego.com/music/saxophone-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:29
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/song-writing
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:33
IP:158.69.209.141
Link:http://lessonsonthego.com/music/song-writing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:35
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/viola-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:39
IP:158.69.209.141
Link:http://lessonsonthego.com/music/viola-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:41
IP:158.69.209.141
Link:http://www.lessonsonthego.com/music/violin-teacher
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:45
IP:158.69.209.141
Link:http://lessonsonthego.com/music/violin-teacher
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:47
IP:158.69.209.141
Link:http://www.lessonsonthego.com/our-staff/blog
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:51
IP:158.69.209.141
Link:http://www.lessonsonthego.com/our-staff/testi
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:55
IP:158.69.209.141
Link:http://lessonsonthego.com/our-staff/testi/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:44:57
IP:158.69.209.141
Link:http://www.lessonsonthego.com/tutors
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:45:03
IP:158.69.209.141
Link:http://www.lessonsonthego.com/tutors/history
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:45:08
IP:158.69.209.141
Link:http://www.lessonsonthego.com/tutors/spanish-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:45:12
IP:158.69.209.141
Link:http://lessonsonthego.com/tutors/spanish-tutoring
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:45:45
IP:108.235.58.9
Link:http://lessonsonthego.com/programs/recitals/commonly-asked-recital-questions/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 563810ab0360af27002
)


2015-11-02 18:54:01
IP:66.249.74.102
Link:http://www.lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 18:55:06
IP:184.154.36.177
Link:http://lessonsonthego.com/th1s_1s_a_4o4.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:24:02
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/slideshow-format/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:24:55
IP:180.76.15.10
Link:http://www.lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:24:58
IP:180.76.15.22
Link:http://lessonsonthego.com/pricing/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:26:00
IP:66.249.79.221
Link:http://lessonsonthego.com/portfolio-archive/gallery-format/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:28:27
IP:68.180.228.97
Link:http://lessonsonthego.com/music/song-writing/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:29:01
IP:66.249.79.221
Link:http://lessonsonthego.com/portfolio-archive/image-format/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:31:07
IP:66.249.79.221
Link:http://lessonsonthego.com/portfolio-archive/slideshow-format/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:33:48
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/audio-format-2/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:35:48
IP:66.249.79.221
Link:http://lessonsonthego.com/portfolio-archive/image-format/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:38:45
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/video-format-2/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:45
IP:157.55.39.240
Link:http://www.lessonsonthego.com/Vocal-Instructors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:46
IP:157.55.39.240
Link:http://www.lessonsonthego.com/music/drum-lessons/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:46
IP:157.55.39.240
Link:http://lessonsonthego.com/music/mandolin-lessons
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:47
IP:157.55.39.240
Link:http://www.lessonsonthego.com/Guitar--Instructors.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:47
IP:157.55.39.240
Link:http://www.lessonsonthego.com/Refund-Policy.html
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:47
IP:157.55.39.240
Link:http://www.lessonsonthego.com/cancellation-policy/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:50
IP:98.199.51.184
Link:http://www.lessonsonthego.com/programs/recitals/recital-registration/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:40:51
IP:98.199.51.184
Link:http://lessonsonthego.com/programs/recitals/recital-registration/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:42:39
IP:66.249.79.228
Link:http://lessonsonthego.com/portfolio-archive/audio-format-2/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:48:17
IP:98.199.51.184
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56381ebcaf02a4fb001
)


2015-11-02 19:48:19
IP:98.199.51.184
Link:http://lessonsonthego.com/images/grab.svg?ver=1.1.6
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [ver] => 1.1.6
    [__atuvs] => 56381ebcaf02a4fb002
)


2015-11-02 19:48:21
IP:98.199.51.184
Link:http://lessonsonthego.com/programs/recitals/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56381ebcaf02a4fb002
)


2015-11-02 19:48:36
IP:98.199.51.184
Link:http://lessonsonthego.com/recital-registration/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 56381ebcaf02a4fb003
)


2015-11-02 19:49:33
IP:178.255.215.74
Link:http://lessonsonthego.com/home/feed/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:49:36
IP:178.255.215.74
Link:http://lessonsonthego.com/home/faqs/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:56:53
IP:66.220.156.99
Link:http://www.lessonsonthego.com/wp-content/uploads/2014/08/logowordpressheader2.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 19:56:54
IP:66.220.156.117
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/logowordpressheader2.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 20:06:16
IP:180.76.15.24
Link:http://www.lessonsonthego.com/lessonsonthego.com/the-unexpected-benefits-of-french-tutoring-for-children/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 20:09:28
IP:66.249.79.228
Link:http://lessonsonthego.com/sitemap-pt-page-2014-08.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 20:17:03
IP:66.249.79.235
Link:http://lessonsonthego.com/careers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 20:18:00
IP:192.171.253.122
Link:http://lessonsonthego.com/wp-content/uploads/2015/05/243-170x143%25402x1.jpg
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 20:21:12
IP:66.249.79.228
Link:http://lessonsonthego.com/testimonial-view/sherrie-l/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 20:23:14
IP:96.19.198.161
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 563826f2c7728a04000
)


2015-11-02 20:32:25
IP:24.147.43.115
Link:http://lessonsonthego.com/team_member/anthony-p/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 20:32:34
IP:24.147.43.115
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 563854fec658260b000
)


2015-11-02 20:45:44
IP:66.249.79.221
Link:http://lessonsonthego.com/sitemap-pt-page-2015-08.xml
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 21:03:27
IP:96.19.198.161
Link:http://lessonsonthego.com/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 21:06:33
IP:96.19.198.161
Link:http://lessonsonthego.com/music/guitar-teachers/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5638321364d20511000
)


2015-11-02 21:06:37
IP:96.19.198.161
Link:http://lessonsonthego.com/wp-content/uploads/2014/08/Fotor080654226.png
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
)


2015-11-02 21:07:20
IP:96.19.198.161
Link:http://lessonsonthego.com/contacts/
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/index.php
Array
(
    [__atuvs] => 5638321364d20511001
)


