<?php exit; ?>
/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php

2015-11-01 13:36:59
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/update.php?action=upload-plugin
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => upload-plugin
    [_wpnonce] => c4b89141fc
    [_wp_http_referer] => /wp-admin/plugin-install.php?tab=upload
    [install-plugin-submit] => Install Now
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 21:51:28
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings-from-static-resources&_wpnonce=514dc6c1de
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings-from-static-resources
    [_wpnonce] => 514dc6c1de
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:51:48
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings-from-static-resources&_wpnonce=514dc6c1de
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings-from-static-resources
    [_wpnonce] => 514dc6c1de
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 22:15:44
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=wp-super-cache-clear-cache-menu&_wpnonce=1600e8ba5d
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => wp-super-cache-clear-cache-menu
    [_wpnonce] => 1600e8ba5d
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:54:58
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings&_wpnonce=410551437e
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings
    [_wpnonce] => 410551437e
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-01 22:55:19
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings&_wpnonce=410551437e
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings
    [_wpnonce] => 410551437e
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-01 22:55:39
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings&_wpnonce=410551437e
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings
    [_wpnonce] => 410551437e
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-01 22:55:59
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings&_wpnonce=410551437e
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings
    [_wpnonce] => 410551437e
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-01 22:56:20
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings&_wpnonce=410551437e
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings
    [_wpnonce] => 410551437e
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-01 22:56:40
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=remove-query-strings&_wpnonce=410551437e
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => remove-query-strings
    [_wpnonce] => 410551437e
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-02 20:51:03
IP:175.100.146.132
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=wp-clone-by-wp-academy&_wpnonce=d399a17929
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => wp-clone-by-wp-academy
    [_wpnonce] => d399a17929
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|b790bdf429f5863a8592d7c1b5491b5351b6eb8237dfa4dcd7e69641f14e6537
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|7ffc8d94214f85062e77093312b79b7997db399775b732f706d5eef7bec9edfa
    [__atuvs] => 56382c1ecf43049f000
)


2015-11-02 20:51:23
IP:175.100.146.132
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=wp-clone-by-wp-academy&_wpnonce=d399a17929
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => wp-clone-by-wp-academy
    [_wpnonce] => d399a17929
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|b790bdf429f5863a8592d7c1b5491b5351b6eb8237dfa4dcd7e69641f14e6537
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|7ffc8d94214f85062e77093312b79b7997db399775b732f706d5eef7bec9edfa
    [__atuvs] => 56382c1ecf43049f000
)


2015-11-02 20:51:43
IP:175.100.146.132
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=wp-clone-by-wp-academy&_wpnonce=d399a17929
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => wp-clone-by-wp-academy
    [_wpnonce] => d399a17929
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|b790bdf429f5863a8592d7c1b5491b5351b6eb8237dfa4dcd7e69641f14e6537
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|7ffc8d94214f85062e77093312b79b7997db399775b732f706d5eef7bec9edfa
    [__atuvs] => 56382c1ecf43049f000
)


2015-11-02 21:07:42
IP:175.100.146.189
Link:http://lessonsonthego.com/wp-admin/update.php?action=install-plugin&plugin=duplicator&_wpnonce=2a6edbe33e
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/update.php
Array
(
    [action] => install-plugin
    [plugin] => duplicator
    [_wpnonce] => 2a6edbe33e
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|b790bdf429f5863a8592d7c1b5491b5351b6eb8237dfa4dcd7e69641f14e6537
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => 26g65prd1ssnnocbvbe1u0vbb4
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446638619|I3Z3QQHVnofrRjTMExBax4VYQq0wixsxW0gNArxVSTz|7ffc8d94214f85062e77093312b79b7997db399775b732f706d5eef7bec9edfa
    [__atuvs] => 56382c1ecf43049f000
)


