<?php exit; ?>
/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/options.php

2015-11-02 03:59:22
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/options.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/options.php
Array
(
    [option_page] => general
    [action] => update
    [_wpnonce] => f6666e2bcc
    [_wp_http_referer] => /wp-admin/options-general.php
    [blogname] => Lessons On The Go
    [blogdescription] => 
    [siteurl] => https://www.lessonsonthego.com
    [home] => https://www.lessonsonthego.com
    [admin_email] => lessonsonthego1@gmail.com
    [default_role] => subscriber
    [timezone_string] => America/Chicago
    [date_format] => d/m/Y
    [date_format_custom] => d/m/Y
    [time_format] => g:i a
    [time_format_custom] => g:i a
    [start_of_week] => 1
    [WPLANG] => 
    [submit] => Save Changes
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvc] => 14|44
    [__atuvs] => 56373b7cc6e7bc1c00b
)


2015-11-02 04:04:29
IP:175.100.147.115
Link:http://lessonsonthego.com/wp-admin/options.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/options.php
Array
(
    [option_page] => general
    [action] => update
    [_wpnonce] => f6666e2bcc
    [_wp_http_referer] => /wp-admin/options-general.php
    [blogname] => Lessons On The Go
    [blogdescription] => 
    [siteurl] => https://www.lessonsonthego.com
    [home] => https://www.lessonsonthego.com
    [admin_email] => lessonsonthego1@gmail.com
    [default_role] => subscriber
    [timezone_string] => America/Chicago
    [date_format] => d/m/Y
    [date_format_custom] => d/m/Y
    [time_format] => g:i a
    [time_format_custom] => g:i a
    [start_of_week] => 1
    [WPLANG] => 
    [submit] => Save Changes
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|a0bf8168e35c3e0a506b6cb5bc635392eefc80ea4e07c8f73dea5859129573c8
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [PHPSESSID] => b9j9m288ul50lipcg632iet026
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446633067|zMrXeGCsS0RuMFA7y32G1Z8JJFbE15iwgrvyo6XZRDW|37f7b8ae2a75bf38aeca7448cec4f090e0b15e9acacf9aa3680f9541295e10d0
    [__atuvc] => 20|44
    [__atuvs] => 56373b7cc6e7bc1c011
)


