<?php
define("ENABLE_COMMON_FILTER", 1);
$CONFIG_EXTRA_FILTER = array();
$CONFIG_EXCLUDE_FOLDERS = array("/webanalyze/firewall/logs/");
define("WEBSITE_ID", "1616");
define("WEBSITE_KEY", "58d405aa5a51b69e5629c7761e382e1b");
?>
