<?php
define("ACCESS_KEY", "5a5accd6c6687480076f4887757f47b4");
?>
