<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'lessony4_sugarland');

/** MySQL database username */
define('DB_USER', 'lessony4_sland');

/** MySQL database password */
define('DB_PASSWORD', 'admin@123#');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '`#2A]T?$t@2Bx3Zc!=LqIV.{(Z]cyazCT5aIf$FSgiZhphjfx; ZRA-[aW3.K$VE');
define('SECURE_AUTH_KEY',  'A{Qx>6!^G S*6IwuD~1$z<#2rbnO5@bv~&S?bG  gYCBAPA 5--DYE*_5vRyLmT{');
define('LOGGED_IN_KEY',    '-z}@=}kq(m&}-H0$<jm$gF~K_j.~nyDh($P/2Zc#=#X30Y4#LMIubzbdM?<TIDY{');
define('NONCE_KEY',        '~c54[cbSSQlF^Hk=hx8YE^{nR=C[g-m-Fe/eCPR-;Zu=.?P^lF~[5]~f{j[wd@iR');
define('AUTH_SALT',        'v$`tW|FC`yf8{G:,B: EWg;fi:5AVQ`;.nLPf|NF2C]0MC3@Es2)OGWR?KOSi>2*');
define('SECURE_AUTH_SALT', '>P*{;iAQQhxooVeA<jH`nOo*}W/}lX_sHE7j9)Z:2o!1bk^=|C46}m]z6H=?b%W3');
define('LOGGED_IN_SALT',   'w1{GAm=b8M~;$?%Gf29j5z!Y}?iG?_,:;KPunh]&CGN?m}+M{V/h,|UwezM~XdNa');
define('NONCE_SALT',       'O_VO[b0u5m|`KgZL1#HzLn+fd&MYx;3}BQe)]rxO|}&&olJ<%Se{69w;*dY~DpHw');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
