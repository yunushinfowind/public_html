$(document).ready(function(){

    var time = 0;

    while (time < 11000) {
        setTimeout (function(){
            $('.c-name > div > .c-editor > input').eq(0).FormPlaceHolder("First name");
            $('.c-name > div > .c-editor > input').eq(1).FormPlaceHolder("Last name");
            $('.c-phone > .c-editor > input').FormPlaceHolder("Phone");
            $('.c-email > .c-editor > input').FormPlaceHolder("Email");
            $('.c-text-singleline > .c-editor > input').eq(0).FormPlaceHolder("Neighbourhood/Area");
            $('.c-text-singleline > .c-editor > input').eq(1).FormPlaceHolder("Zip code");
            $('.cognito > div').remove();
            
        }, time);
        time += 1000;
    }

    $('.testimonial-slider').unslider({arrows: false, autoplay: true, pause: true, delay: 6000});
    
    $('.testimonial-slider').unslider('initSwipe');

    $('.testimonial-slider').on('mouseover', function() { $('.testimonial-slider').unslider('stop');}).on('mouseout', function() { $('.testimonial-slider').unslider('start');
});
});


$.fn.FormPlaceHolder=function(x) {
    this.attr('style', "color: #bbbbbb;");
    this.attr("placeholder", x);
        $(this).focus(function(){ 
            if ($(this).val() == x) { $(this).val("");  }  
            $(this).attr('style', "color: #bbbbbb;");  

        });
        $(this).blur(function(){  if ( $(this).val() == "" || !/\S/.test($(this).val()) )  
            { $(this).attr("placeholder", x).attr('style', "color: #bbbbbb;");} });
};