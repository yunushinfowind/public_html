<?php exit; ?>
/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php

2015-11-01 12:20:53
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 8888185657
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446367757|gBShNUx0yJpyWch4MJaJTOdXNNFrVkldC8MpQ3EWJlz|5bc3e7a49fe0fe425cdb3f0b903b0189c013cac8942db5aba4f942cf5767d7ad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446367757|gBShNUx0yJpyWch4MJaJTOdXNNFrVkldC8MpQ3EWJlz|52333a079c83de7bc56233c05a0e418752d7d77b4a8f2c04479af2909c63ab39
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D15%26sessionPageCount%3D2%26lastVisitedAt%3D1446207563161%26weeklySessionCount%3D11%26lastSessionAt%3D1446204476490
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
)


2015-11-01 12:21:53
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 8888185657
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D15%26sessionPageCount%3D2%26lastVisitedAt%3D1446207563161%26weeklySessionCount%3D11%26lastSessionAt%3D1446204476490
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 12:23:53
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 8888185657
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D15%26sessionPageCount%3D2%26lastVisitedAt%3D1446207563161%26weeklySessionCount%3D11%26lastSessionAt%3D1446204476490
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 12:25:54
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 8888185657
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D15%26sessionPageCount%3D2%26lastVisitedAt%3D1446207563161%26weeklySessionCount%3D11%26lastSessionAt%3D1446204476490
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 12:27:53
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 8888185657
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D15%26sessionPageCount%3D2%26lastVisitedAt%3D1446207563161%26weeklySessionCount%3D11%26lastSessionAt%3D1446204476490
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 12:29:53
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 8888185657
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D15%26sessionPageCount%3D2%26lastVisitedAt%3D1446207563161%26weeklySessionCount%3D11%26lastSessionAt%3D1446204476490
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-01 12:39:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php?action=dashboard-widgets&widget=dashboard_primary&pagenow=dashboard
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => dashboard-widgets
    [widget] => dashboard_primary
    [pagenow] => dashboard
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:39:53
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 8888185657
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => header-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:07
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => optimization-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => typography-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:21
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:21
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => 300
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => ABeeZee
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:23
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => ABeeZee
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:46
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => pagination-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:40:56
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => general-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => grid-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:05
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => layouts-subsection
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:09
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => blog-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => post-meta-subsection
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:26
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => post-single-subsection
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:35
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => styling-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:41
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => color-subsection
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:43
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => navigation-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:44
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:44
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:47
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => breadcrumbs-subsection
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:41:59
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => page-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:42:04
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:42:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:42:25
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => social-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:42:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => cookie-banner-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:42:40
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => demo-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:42:44
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Abril Fatface
            [style] => regular
            [character] => Array
                (
                    [0] => latin-ext
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:43:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:44:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:44:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:46:04
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:46:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:48:04
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:48:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:50:05
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:50:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 12:52:06
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:20:01
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:21:01
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:23:01
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:25:02
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:27:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:29:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:36:28
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:37:01
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:38:01
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:40:02
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [__atuvc] => 499|43
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
)


2015-11-01 13:40:18
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => post_type
    [object] => page
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:18
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => post_type
    [object] => post
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => post_type
    [object] => team
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => post_type
    [object] => service
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => post_type
    [object] => portfolio
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => post_type
    [object] => testimonial
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:19
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => post_type
    [object] => team_member
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => category
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => post_tag
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:20
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => post_format
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:21
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => team_member_position
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:21
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => testimonial_position
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:21
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => portfolio_category
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => portfolio_tag
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:22
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => service_category
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:23
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => group
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:40:23
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [customize-menus-nonce] => c1cf4364fd
    [wp_customize] => on
    [type] => taxonomy
    [object] => testimonial_category
    [page] => 0
    [action] => load-available-menu-items-customizer
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [gk_last_opened_widget_rules_wrap] => 0
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
)


2015-11-01 13:42:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [__atuvc] => 499|43,1|44
    [__atuvs] => 563678ae07dca15f000
    [gk_last_opened_widget_rules_wrap] => 0
)


2015-11-01 13:44:03
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:44:24
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => settings_page_google-sitemap-generator/sitemap
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:45:59
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => settings_page_google-sitemap-generator/sitemap
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:46:04
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:47:59
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => settings_page_google-sitemap-generator/sitemap
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:48:59
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => settings_page_google-sitemap-generator/sitemap
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:50:08
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:50:55
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:51:08
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:52:55
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:53:08
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:54:55
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:55:08
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,2|44
    [__atuvs] => 563678ae07dca15f001
)


2015-11-01 13:56:55
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 13:57:08
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 13:58:55
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 13:59:08
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:00:55
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:02:55
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:04:56
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:05:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:05:56
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => toplevel_page_plgavp_Antivirus
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:06:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:07:37
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => settings_page_google-sitemap-generator/sitemap
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:08:35
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:08:37
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 0e9042bf16
    [action] => heartbeat
    [screen_id] => settings_page_google-sitemap-generator/sitemap
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|a09aee0b12f141804f797a367a4e96a9793e06226e9dec61fcd54ba0e0e1c7ba
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446579553|BDEYaPaWLmWUKagi20AUfU0aevdnLLxOWrmraj81caE|5b216530d1722db5adf75aa3bcab097daa5f842cb84afe3d1e49c0d7e871bf30
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D16%26sessionPageCount%3D1%26lastVisitedAt%3D1446406760767%26weeklySessionCount%3D12%26lastSessionAt%3D1446406760767
    [gk_last_opened_widget_rules_wrap] => 0
    [__atuvc] => 499|43,3|44
    [__atuvs] => 563678ae07dca15f002
)


2015-11-01 14:43:29
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => breadcrumbs-subsection
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:31
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => typography-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:33
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:33
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => 300
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => ABeeZee
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:43:34
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => ABeeZee
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:44:29
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:46:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:47:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:49:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:51:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:53:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:55:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 14:57:30
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:02:08
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:02:15
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => footer-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:02:16
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_google_font_link
    [font_data] => Array
        (
            [family] => Open Sans
            [style] => regular
            [character] => Array
                (
                    [0] => latin
                )

        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:03:07
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:04:07
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:04:12
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => cherry_save_options
    [post_array] => Array
        (
            [footer-background] => Array
                (
                    [image] => 
                    [color] => #59ccdb
                    [repeat] => repeat
                    [position] => left
                    [attachment] => fixed
                )

            [typography-footer] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 16
                    [lineheight] => 24
                    [letterspacing] => 
                    [color] => #333333
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [footer-grid-type] => wide
            [footer-boxed-width] => 1310
            [footer-text] => <p><span id="siteseal"><script type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=ayo4W6qfpO0jg2k83FNm8cgU5x0jjWklbio7rjcxHzr3XypTQ3iG9ufEfYCh"></script></span></p>
<p><!-- (c) 2005, 2015. Authorize.Net is a registered trademark of CyberSource Corporation --> <div class="AuthorizeNetSeal"> <script type="text/javascript" language="javascript">var ANS_customer_id="2a0eb0a8-41ab-4e03-988b-3ddede3d6ea9";</script> <script type="text/javascript" language="javascript" src="//verify.authorize.net/anetseal/seal.js" ></script> <a href="http://www.authorize.net/" id="AuthorizeNetText" target="_blank">Online Payment Service</a> </div>	</p>
            [typography-body] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 16
                    [lineheight] => 24
                    [letterspacing] => 
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [color-link] => #343a41
            [color-link-hover] => #81c5c5
            [typography-input-text] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 14
                    [lineheight] => 20
                    [letterspacing] => 
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-breadcrumbs] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 18
                    [lineheight] => 24
                    [letterspacing] => 
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h1] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 30
                    [lineheight] => 32
                    [letterspacing] => 
                    [color] => #81c5c5
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h2] => Array
                (
                    [family] => Open Sans
                    [style] => 300
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 45
                    [lineheight] => 48
                    [letterspacing] => 0
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h3] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 20
                    [lineheight] => 24
                    [letterspacing] => 0
                    [color] => #81c5c5
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h4] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 21
                    [lineheight] => 22
                    [letterspacing] => 0
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h5] => Array
                (
                    [family] => ABeeZee
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 14
                    [lineheight] => 16
                    [letterspacing] => 0
                    [color] => #333333
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h6] => Array
                (
                    [family] => ABeeZee
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 12
                    [lineheight] => 14
                    [letterspacing] => 0
                    [color] => #333333
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [webfonts] => ABeeZee
            [breadcrumbs] => false
            [breadcrumbs-show-title] => false
            [breadcrumbs-display] => Array
                (
                    [mobile] => true
                    [tablet] => true
                )

            [breadcrumbs-show-on-front] => false
            [breadcrumbs-home-title] => true
            [breadcrumbs-custom-home-title] => Home
            [breadcrumbs-separator] => /
            [breadcrumbs-prefix-path] => 
        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [__atuvc] => 499|43,5|44
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
)


2015-11-01 16:05:07
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:06:07
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:07:07
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:08:10
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:08:29
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => cherry_save_options
    [post_array] => Array
        (
            [footer-background] => Array
                (
                    [image] => 
                    [color] => #59ccdb
                    [repeat] => repeat
                    [position] => left
                    [attachment] => fixed
                )

            [typography-footer] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 16
                    [lineheight] => 24
                    [letterspacing] => 
                    [color] => #333333
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [footer-grid-type] => wide
            [footer-boxed-width] => 1310
            [footer-text] => 
            [typography-body] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 16
                    [lineheight] => 24
                    [letterspacing] => 
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [color-link] => #343a41
            [color-link-hover] => #81c5c5
            [typography-input-text] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 14
                    [lineheight] => 20
                    [letterspacing] => 
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-breadcrumbs] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 18
                    [lineheight] => 24
                    [letterspacing] => 
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h1] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 30
                    [lineheight] => 32
                    [letterspacing] => 
                    [color] => #81c5c5
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h2] => Array
                (
                    [family] => Open Sans
                    [style] => 300
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 45
                    [lineheight] => 48
                    [letterspacing] => 0
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h3] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 20
                    [lineheight] => 24
                    [letterspacing] => 0
                    [color] => #81c5c5
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h4] => Array
                (
                    [family] => Open Sans
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 21
                    [lineheight] => 22
                    [letterspacing] => 0
                    [color] => #343a41
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h5] => Array
                (
                    [family] => ABeeZee
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 14
                    [lineheight] => 16
                    [letterspacing] => 0
                    [color] => #333333
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [typography-h6] => Array
                (
                    [family] => ABeeZee
                    [style] => regular
                    [character] => Array
                        (
                            [0] => latin
                        )

                    [size] => 12
                    [lineheight] => 14
                    [letterspacing] => 0
                    [color] => #333333
                    [align] => notdefined
                    [category] => 
                    [fonttype] => web
                )

            [webfonts] => ABeeZee
            [breadcrumbs] => false
            [breadcrumbs-show-title] => false
            [breadcrumbs-display] => Array
                (
                    [mobile] => true
                    [tablet] => true
                )

            [breadcrumbs-show-on-front] => false
            [breadcrumbs-home-title] => true
            [breadcrumbs-custom-home-title] => Home
            [breadcrumbs-separator] => /
            [breadcrumbs-prefix-path] => 
        )

    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:09:10
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:11:10
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:13:11
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:15:10
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 16:17:10
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 13811d2a6b
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|539b0c66ad02baf45aa00c1e85b80a3671a894c85bd2d6d5ac337fa31904adad
    [PHPSESSID] => 092j8h0sloe85otup9qv9o78b5
    [cf-cookie-banner] => 
    [_ga] => GA1.2.1100496237.1445823911
    [__atssc] => google;1
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446211156
    [gk_last_opened_widget_rules_wrap] => 0
    [wordpress_test_cookie] => WP Cookie check
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446586998|4MbKiLUEnnZY9vEuZpSlUfz31k3PSZ0kBp7xoh2eTZl|ad314d342fc066be22aab837090b578a86ebe42d563ee470db67aced154221a3
    [_drip_client_6994213] => vid%3Deb1a5c805e9a0133705d0e9dd67883c3%26pageViews%3D17%26sessionPageCount%3D1%26lastVisitedAt%3D1446414203461%26weeklySessionCount%3D13%26lastSessionAt%3D1446414203461
    [__atuvc] => 499|43,6|44
    [__atuvs] => 56369a75f4f55127000
)


2015-11-01 21:39:29
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php?action=dashboard-widgets&widget=dashboard_primary&pagenow=dashboard
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => dashboard-widgets
    [widget] => dashboard_primary
    [pagenow] => dashboard
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
)


2015-11-01 21:40:28
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:41:28
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:43:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:45:28
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:46:29
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:48:29
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:50:14
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:54:35
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:55:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 21:59:18
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 22:01:19
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 22:03:18
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 22:05:18
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 22:06:25
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 1|44
    [__atuvs] => 5636e914599840f3000
)


2015-11-01 22:09:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:14:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:14:40
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => motopress_page_motopress_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:16:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:18:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:18:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:19:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:19:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:20:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:21:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:21:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:22:38
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:22:40
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:23:00
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => general-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:23:14
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => get_options_section
    [active_section] => optimization-section
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:23:38
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:24:00
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:24:38
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:24:41
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => antivirus_page_plgavp_Antivirus_settings_page
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:25:55
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:25:56
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => antivirus_page_plgavp_Antivirus_settings_page
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:26:00
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:26:56
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:28:01
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:28:16
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => antivirus_page_plgavp_Antivirus_settings_page
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:28:55
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:29:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => antivirus_page_plgavp_Antivirus_settings_page
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:29:55
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => plugins
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:30:01
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => cherry_page_options
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:31:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => 668004a837
    [action] => heartbeat
    [screen_id] => antivirus_page_plgavp_Antivirus_settings_page
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|545cc44e5e74d692d54ab5dbdc901dadb849dd7a324a18edf84d989a84e707c1
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446611945|fjRa9sFB5Yvw3fx84F6zDvrv6lGT9vlQmn4dgStlzcA|399a24b0383b06cffce5043d01f7e168e4ba9d2600aafe5528b759128fee64b2
    [PHPSESSID] => gt02hmbb3d8oeq3v0r10t4aui7
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446439156
    [_drip_client_6994213] => vid%3Da0efe850634901338e810e9dd67883c3%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446439169752%26weeklySessionCount%3D1%26lastSessionAt%3D1446439169752
    [__atuvc] => 2|44
    [__atuvs] => 5636e914599840f3001
)


2015-11-01 22:39:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php?action=dashboard-widgets&widget=dashboard_primary&pagenow=dashboard
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => dashboard-widgets
    [widget] => dashboard_primary
    [pagenow] => dashboard
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [__atuvs] => 5636f6bbb0797b29000
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
)


2015-11-01 22:40:33
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => c21ad1b73a
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [__atuvc] => 1|44
    [__atuvs] => 5636f6bbb0797b29000
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446442775571%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
)


2015-11-01 22:41:34
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => c21ad1b73a
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [__atuvc] => 1|44
    [__atuvs] => 5636f6bbb0797b29000
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446442775571%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
)


2015-11-01 22:47:13
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => c21ad1b73a
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [__atuvc] => 1|44
    [__atuvs] => 5636f6bbb0797b29000
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446442775571%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
)


2015-11-01 22:48:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => c21ad1b73a
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [__atuvc] => 1|44
    [__atuvs] => 5636f6bbb0797b29000
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446442775571%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
)


2015-11-01 22:48:25
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php?action=dashboard-widgets&widget=dashboard_primary&pagenow=dashboard
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => dashboard-widgets
    [widget] => dashboard_primary
    [pagenow] => dashboard
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [__atuvs] => 5636f6bbb0797b29000
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D1%26sessionPageCount%3D1%26lastVisitedAt%3D1446442775571%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
)


2015-11-01 22:53:17
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => c21ad1b73a
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => true
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvc] => 2|44
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-01 22:55:15
IP:175.100.147.36
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [interval] => 60
    [_nonce] => c21ad1b73a
    [action] => heartbeat
    [screen_id] => plugin-install
    [has_focus] => false
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|538ae908cd92e747210f32b4193b474cf8d742dfa8a7e66e0be6ddf297a74e8d
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446615567|R31xQpJMyPpPVx3KNeYBNIIbNucfwSPntf0hafi5skx|1da848e2747f6122fa8c49d8cf36df6b58b82afa5557933ae7636ad6e3ea8aec
    [PHPSESSID] => n1hrqgb90qun7dudh8vblphkd2
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show&wplink=1&align=center&imgsize=thumbnail
    [wp-settings-time-1] => 1446442769
    [_drip_client_6994213] => vid%3D06365030635201336f250ee7875afa48%26pageViews%3D2%26sessionPageCount%3D2%26lastVisitedAt%3D1446443305882%26weeklySessionCount%3D1%26lastSessionAt%3D1446442775571
    [__atuvc] => 2|44
    [__atuvs] => 5636f6bbb0797b29001
)


2015-11-02 01:57:22
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
)


2015-11-02 01:57:23
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [action] => revslider_ajax_action
    [client_action] => update_plugin
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 01:57:25
IP:82.146.36.221
Link:http://www.lessonsonthego.com/wp-admin/admin-ajax.php?page=pmxi-admin-settings&action=upload&name=db.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [page] => pmxi-admin-settings
    [action] => upload
    [name] => db.php
    [PHPSESSID] => t5q8qff3p69s6sqofvma2818i7
)


2015-11-02 19:27:07
IP:76.31.253.156
Link:http://lessonsonthego.com/wp-admin/admin-ajax.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/wp-admin/admin-ajax.php
Array
(
    [data] => Array
        (
            [wp-auth-check] => true
        )

    [interval] => 60
    [_nonce] => 8f4ebeac34
    [action] => heartbeat
    [screen_id] => dashboard
    [has_focus] => true
    [0aa9956a9d515584e27e34537cd687e4device_type] => Desktop
    [wordpress_sec_0aa9956a9d515584e27e34537cd687e4] => admin|1446148826|Aq3gSvdcrSvYhlA4rQuFXv33e1ZOq1fjpAfGMVAe9ur|482982d73d05d25c02c4ffe22f4733e2bf371f541bf9266beecaada9a4f72a89
    [PHPSESSID] => nui2chde95rvgolrh415p83vd0
    [wp_lead_uid] => 2ciSUFzhnpmy6WCJqRLftiwU6nQIxbhWKkg
    [inbound_referral_site] => https://www.bing.com/
    [lead_session] => 40
    [wordpress_test_cookie] => WP Cookie check
    [cf-cookie-banner] => 
    [__atuvc] => 10|42,11|43
    [_ga] => GA1.2.411924502.1445538707
    [wordpress_logged_in_0aa9956a9d515584e27e34537cd687e4] => admin|1446148826|Aq3gSvdcrSvYhlA4rQuFXv33e1ZOq1fjpAfGMVAe9ur|0f3fc542e746bd5e7af161a2f75123fc19bc9040f0809c3d49350b879283ed60
    [wp-settings-1] => libraryContent=browse&editor=tinymce&posts_list_mode=list&post_dfw=off&hidetb=1&advImgDetails=show
    [wp-settings-time-1] => 1445976027
)


