<?php exit; ?>
/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/xmlrpc.php

2015-11-01 06:55:23
IP:173.236.59.218
Link:http://lessonsonthego.com/xmlrpc.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/xmlrpc.php
Array
(
)


2015-11-01 06:55:23
IP:173.236.59.218
Link:http://lessonsonthego.com/xmlrpc.php?rsd
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/xmlrpc.php
Array
(
    [rsd] => 
)


2015-11-01 07:53:39
IP:91.99.25.115
Link:http://www.lessonsonthego.com/xmlrpc.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/xmlrpc.php
Array
(
)


2015-11-01 14:31:56
IP:184.154.36.178
Link:http://lessonsonthego.com/xmlrpc.php?rsd
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/xmlrpc.php
Array
(
    [rsd] => 
    [wordpress_test_cookie] => WP Cookie check
)


2015-11-02 06:53:30
IP:67.212.188.154
Link:http://lessonsonthego.com/xmlrpc.php
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/xmlrpc.php
Array
(
)


2015-11-02 06:53:31
IP:67.212.188.154
Link:http://lessonsonthego.com/xmlrpc.php?rsd
File:/var/chroot/home/content/p3pnexwpnas07_data01/45/2597545/html/xmlrpc.php
Array
(
    [rsd] => 
)


